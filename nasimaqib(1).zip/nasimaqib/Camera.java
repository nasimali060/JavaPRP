package nasimaqib;

import java.util.Hashtable;

import javax.swing.JLabel;
import javax.swing.JSlider;

/**
 * This class represents a Camera
 * 
 * @author Nasim Ali
 * @author Aqib Rashid
 *
 */

public class Camera extends JSlider {

	/**
	 * Creates a new instance of Camera
	 */
	public Camera() {
		super(0, 15);
		createSlider(); // Separation into logical subsets and methods
	}

	/*
	 * Creates the Slider component by taking characters from a string and
	 * populating a hashtable
	 */
	private void createSlider() {
		Hashtable<Integer, JLabel> labels = new Hashtable<>();
		String digits = "0123456789ABCDEF"; // String of 0-15 in HEX
		for (int i = 0; i < digits.length(); i++) {
			char current = digits.charAt(i);
			labels.put(i, new JLabel(Character.toString(current)));
		}
		setPaintLabels(true);
		setLabelTable(labels);
		setValue(0);
	}

	/**
	 * Method which moves the Camera based on input
	 * 
	 * @param input
	 */
	public void move(int[] input) {
		for (int i = 0; i < input.length; i++) {
			this.setValue(input[i]);
			try {
				Thread.sleep(1500);
			} catch (Exception e) {

			}
		}
	}

}
