package nasimaqib;

import java.io.IOException;
/**
 * Main tester class
 * @author Nasim Ali
 * @author Aqib Rashid
 *
 */
public class Main {

	public static void main(String[] args) throws IOException {

		new Communication().setVisible(true); // Launch the Communication frame

	}
}
