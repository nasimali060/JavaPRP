package nasimaqib;

import java.awt.BorderLayout; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

/**
 * This class represents a Communication frame
 * 
 * @author Nasim Ali
 * @author Aqib Rashid
 *
 */

public class Communication extends JFrame {
	private Camera camera;
	private JTextArea jtaMessage;
	private JButton jbSend;

	/**
	 * Creates a new Communication frame
	 */
	public Communication() {
		// Setting up the frame
		super("NASA Communication");
		createWidgets(); // Separation into logical subsets and methods
	}

	/*
	 * Sets up all the widgets and adds them to the frame
	 */
	private void createWidgets() {
		setSize(500, 500);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Adding components
		camera = new Camera();
		add(camera, BorderLayout.NORTH);

		jtaMessage = new JTextArea();
		add(jtaMessage, BorderLayout.CENTER);

		jbSend = new JButton("Send");
		add(jbSend, BorderLayout.SOUTH);
		jbSend.addActionListener(new ActionListener() { // Anonymous inner class

			@Override
			public void actionPerformed(ActionEvent e) {
				send(jtaMessage.getText()); // Retrieve the text in the textarea
				jtaMessage.setText(""); // CWK requirement to clear textarea

			}
		});
	}

	/*
	 * Sends a message after converting
	 */
	private void send(String message) {
		Thread moveThread = new Thread(new Runnable() { // Anonymous inner class
			public void run() {
				int[] input = new int[message.length()]; // Create an array of hex codes
				try {
					input = convert(message); // Convert message
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Communication.this.setTitle("Sending..."); // Title change
				camera.move(input);
				Communication.this.setTitle("NASA Communication"); // Resets

			}
		});

		moveThread.start(); // Start the thread
	}

	/*
	 * Convert the message into an array of ints consisting of hex codes
	 */
	private int[] convert(String message) throws IOException {

		// Populate with array of ASCIIs
		int[] inputAscii = getAsciiArray(message);

		// Load file and store in Map
		Map<Integer, String> asciiTable = loadFile("ascii_table.csv");

		/*
		 * Locate the hex codes and store as a String. This allows for easy
		 * breaking up later
		 */
		String hexCodeString = locateHex(message, asciiTable, inputAscii);

		// Create a final array of ints
		int[] singleHex = createFinalHexArray(hexCodeString);

		return singleHex;
	}

	/*
	 * Get ASCII of each char in message and store in array using simple casting
	 * and return array of ints
	 */
	private int[] getAsciiArray(String entry) {

		int[] inputAscii = new int[entry.length()]; // int size of entry
		for (int i = 0; i < inputAscii.length; i++) {
			inputAscii[i] = (int) entry.toCharArray()[i]; // Locate ASCII
		}

		return inputAscii;
	}

	/*
	 * Create a Map from the loaded ASCII table file. Store the first column
	 * (ASCII) and then the third (HEX). ASCII is always a number so it is stored
	 * as int. HEX can contain letters so it is a String. 
	 * Returns the ASCII table Map
	 */
	private Map<Integer, String> loadFile(String fileName) throws FileNotFoundException {
		Map<Integer, String> asciiTable = new HashMap<>();
		Scanner reader = new Scanner(new File("ascii_table.csv"));
		reader.nextLine();// Skip the headers in the file
		while (reader.hasNextLine()) {
			String[] csV = reader.nextLine().split(",");
			// ASCII is always a number, hence we parse as int
			asciiTable.put(Integer.parseInt(csV[0]), csV[2]);
		}
		reader.close(); // Always close the Scanner
		return asciiTable;
	}

	/*
	 * Create a String of HEX codes from the Map. Uses the ASCII array and the
	 * uses the ints as a key. Storing this as a String allows us to split up
	 * easily (for later). Returns the concatenated HEX code String
	 */
	private String locateHex(String entry, Map<Integer, String> asciiTable, int[] inputAscii) {
		String hexCodeString = "";
		for (int i = 0; i < entry.length(); i++) {
			hexCodeString += asciiTable.get(inputAscii[i]); // Use ASCII as the key
		}
		return hexCodeString;
	}

	/*
	 * Finalises the array of HEX codes as ints. Since some digits are letters in HEX
	 * they must be converted to their respective number representations. 
	 * Returns the final pure number HEX code array
	 */
	private int[] createFinalHexArray(String hexCodeString) {
		int[] finalHex = new int[hexCodeString.length()];
		for (int i = 0; i < finalHex.length; i++) {
			char current = hexCodeString.toCharArray()[i]; // Convert to array of char and retrieve each one
			if (Character.isLetter(current)) { // Checks if current is a letter. If so, converts
				String digits = "0123456789ABCDEF"; // String of 0-15 in HEX
				finalHex[i] = digits.indexOf(current); // Will retrieve the index
			} else { // It is a number, so add to the array
				finalHex[i] = Character.getNumericValue(current); // Prevents casting issues
			}

		}
		return finalHex;
	}

}
