package nasimradhika;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;

import javax.swing.JLabel;
import javax.swing.JPanel;
import generator.Media;

/**
 * This class contains the methods that will be used in the action listeners in the Media Frame class to sort 
 * out the thumb nails according to the users wishes 
 * @author Nasim
 * @author Radhika
 *
 */

public class SortedThumbNails {
	
	PatternMatching pm;
	
	/**
	 * A PatternMatching class is passed through this class
	 * @param pm a PatternMatching Object
	 */
	public SortedThumbNails(PatternMatching pm){
		this.pm = pm;
	}
	
	/**
	 * A TreeMap was used to sort out the Film titles by alphabetical order, a tree map does this automatically
	 * and then is passed to the JPanel for viewing.
	 * @param filmThumbPanel a JPanel Object
	 */
	protected void sortFilmTitle(JPanel filmThumbPanel){
		TreeMap <String, Media> filmTitle = new TreeMap<>();
		
		for (Media media: pm.filmMatching()){
			filmTitle.put(pm.filmNameSeperatingThe(media.getName()), media);
		}
		for (String name: filmTitle.keySet()){
			JPanel jpIndividPanel = new JPanel(new BorderLayout());
			jpIndividPanel.add(filmTitle.get(name).getImage(), BorderLayout.NORTH);
			jpIndividPanel.add(new JLabel (pm.filmNameSeperation(filmTitle.get(name).getName())), BorderLayout.CENTER);
			jpIndividPanel.add(new JLabel(pm.filmYearReleasedSeperation(filmTitle.get(name).getName())+
					" - "+pm.filmDefinitionSeperation(filmTitle.get(name).getName())), BorderLayout.SOUTH);
			
			filmThumbPanel.add(jpIndividPanel);
		}
	}
	
	/**
	 * A method similar structure to the method above, this method will structure the Media in the map so they 
	 * are sorted according to year, and used Collections.reverseOrder to structure them so the latest is first
	 * which will be the highest number, and then is passed to the JPanel for viewing.
	 * 
	 * @param filmThumbPanel a JPanel object
	 */
	protected void sortFilmYear(JPanel filmThumbPanel){
		TreeMap <String, Media> filmYear = new TreeMap<>(Collections.reverseOrder());
		for (Media media: pm.filmMatching()){
			filmYear.put(pm.filmYearReleasedSeperation(media.getName()), media);
		}
		for (String year: filmYear.keySet()){
			JPanel jpIndividPanel = new JPanel(new BorderLayout());
			jpIndividPanel.add(filmYear.get(year).getImage(), BorderLayout.NORTH);
			jpIndividPanel.add(new JLabel (pm.filmNameSeperation(filmYear.get(year).getName())), BorderLayout.CENTER);
			jpIndividPanel.add(new JLabel(year+ " - "+pm.filmDefinitionSeperation(filmYear.get(year).getName())), 
					BorderLayout.SOUTH);
			filmThumbPanel.add(jpIndividPanel);
		}
	}
	
	/**
	 * This method first sorts the film definition by definition then adds them to an Arraylist, and then adds 
	 * them to the panel.
	 * @param filmThumbPanel a JPanel object
	 */
	protected void sortFilmDefinition(JPanel filmThumbPanel){
		ArrayList<Media> lol = new ArrayList<>();
		for (Media media : pm.filmMatching()){
			if (pm.filmDefinitionSeperation(media.getName()).equals("(HD, 1080p)")){
				lol.add(media);
			}
		}
		
		for (Media media : pm.filmMatching()){
			if (pm.filmDefinitionSeperation(media.getName()).equals("(HD, 720p)")){
				lol.add(media);
			}
		}
		
		for (Media media : pm.filmMatching()){
			if (pm.filmDefinitionSeperation(media.getName()).equals("(SD, 480p)")){
				lol.add(media);
			}
		}
		
		for (Media media : lol){
			JPanel jpIndividPanel = new JPanel(new BorderLayout());
			jpIndividPanel.add(media.getImage(), BorderLayout.NORTH);
			jpIndividPanel.add(new JLabel (pm.filmNameSeperation(media.getName())), BorderLayout.CENTER);
			jpIndividPanel.add(new JLabel(pm.filmYearReleasedSeperation(media.getName())+" - "+pm.filmDefinitionSeperation(media.getName())), BorderLayout.SOUTH);
			filmThumbPanel.add(jpIndividPanel);
		}
		
	}
	/**
	 * A TreeMap was used to sort out the Film titles by alphabetical order, a tree map does this automatically
	 * and then is passed to the JPanel for viewing.
	 * @param musicThumbPanel a JPanel object
	 */
	protected void sortMusicName(JPanel musicThumbPanel){
		TreeMap <String, Media> musicTitle = new TreeMap<>();
		
		for (Media media: pm.musicMatching()){
			musicTitle.put(pm.getMusicTitleSeperatingThe(media.getName()), media);
		}
		
		for (String name: musicTitle.keySet()){
			JPanel jpIndividPanel = new JPanel(new BorderLayout());
			jpIndividPanel.add(musicTitle.get(name).getImage(), BorderLayout.NORTH);
			jpIndividPanel.add(new JLabel(pm.getMusicTitle(musicTitle.get(name).getName())), BorderLayout.CENTER);
			jpIndividPanel.add(new JLabel(pm.musicArtistsSeperation(musicTitle.get(name).getName())),BorderLayout.SOUTH);
			musicThumbPanel.add(jpIndividPanel);
		}
		
	}
	
	/**
	 * A TreeMap was used to sort out the Film titles by alphabetical order, a tree map does this automatically
	 * and then is passed to the JPanel for viewing.
	 * @param musicThumbPanel a JPanel object
	 */
	protected void sortArtistName(JPanel musicThumbPanel){
		TreeMap <String, Media> musicArtists = new TreeMap<>();
		
		for (Media media: pm.musicMatching()){
			musicArtists.put(pm.musicArtistsSeperation(media.getName()), media);
		}
		for (String name: musicArtists.keySet()){
			JPanel jpIndividPanel = new JPanel(new BorderLayout());
			jpIndividPanel.add(musicArtists.get(name).getImage(), BorderLayout.NORTH);
			jpIndividPanel.add(new JLabel(pm.getMusicTitle(musicArtists.get(name).getName())), BorderLayout.CENTER);
			jpIndividPanel.add(new JLabel(pm.musicArtistsSeperation(musicArtists.get(name).getName())),BorderLayout.SOUTH);
			musicThumbPanel.add(jpIndividPanel);
		}
	}
	

}
