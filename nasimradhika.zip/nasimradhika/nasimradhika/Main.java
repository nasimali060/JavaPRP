package nasimradhika;
/**
 * 
 * @author Nasim
 * @author Radhika
 *
 */
public class Main {
	
	public static void main(String [] args){
		MediaFrame mf = new MediaFrame();
		mf.setVisible(true);
	}

}
