package nasimradhika;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import generator.Media;
/**
 * 
 * @author Nasim
 * @author Radhika
 *
 */

public class MediaFrame extends JFrame {

	private static final long serialVersionUID = -8290434941045852097L;
	
	JPanel filmThumbPanel;
	JPanel musicThumbPanel;
	JPanel unclassThumbPanel;
	PatternMatching pm;
	SortedThumbNails srtThumbNails;
	
	/**
	 * The constructor so when called will properly construct the class which extends JFrame
	 */
	public MediaFrame(){
		super("Media");
		this.setSize(600,800);
		pm = new PatternMatching();
		srtThumbNails = new SortedThumbNails(pm);
		filmPanel();
		musicPanel();
		unclassPanel();
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(3,1));
	}
	
	/**
	 * This method will create the FilmPanel section and contains an anonymous inner class for the action 
	 * listener for the JComboBox options
	 */
	private void filmPanel(){
		JPanel filmPanel = new JPanel(new BorderLayout());
		filmThumbPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		makeFilmThumbNails();
		JScrollPane scroll = new JScrollPane(filmThumbPanel,JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		filmPanel.add(scroll, BorderLayout.CENTER);
		String[] filmChoices = {"Sort","Title","Release Year","Quality"};
		JComboBox<String> jcbFilm = new JComboBox<String>(filmChoices);
		jcbFilm.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				if (jcbFilm.getSelectedItem().toString().equals("Sort")){
					//Do nothing LoL
				}
				else if(jcbFilm.getSelectedItem().toString().equals("Title")){
					filmThumbPanel.removeAll();
					srtThumbNails.sortFilmTitle(filmThumbPanel);
					filmThumbPanel.revalidate();
					filmThumbPanel.repaint();
				}
				else if(jcbFilm.getSelectedItem().toString().equals("Release Year")){
					filmThumbPanel.removeAll();
					srtThumbNails.sortFilmYear(filmThumbPanel);
					filmThumbPanel.revalidate();
					filmThumbPanel.repaint();
				}
				else if (jcbFilm.getSelectedItem().toString().equals("Quality")){
					filmThumbPanel.removeAll();
					srtThumbNails.sortFilmDefinition(filmThumbPanel);
					filmThumbPanel.revalidate();
					filmThumbPanel.repaint();
				}
				
			}
			
		});
		JPanel jpTypeOptions = new JPanel(new BorderLayout());
		jpTypeOptions.add(new JLabel ("Films"), BorderLayout.WEST);
		jpTypeOptions.add(jcbFilm, BorderLayout.EAST);
		filmPanel.add(jpTypeOptions, BorderLayout.NORTH);
		this.add(filmPanel);

	}
	
	/**
	 * This method will create the Music Panel section, and also contains the anonymous inner class for 
	 * the action listener for the JComboBox options
	 */
	private void musicPanel(){
		JPanel musicPanel = new JPanel(new BorderLayout());
		musicThumbPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		makeMusicThumbNails();
		JScrollPane scroll = new JScrollPane(musicThumbPanel,JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		musicPanel.add(scroll, BorderLayout.CENTER);
		String[] musicChoices = {"Sort","Track Name","Artist"};
		JComboBox<String> jcbMusic = new JComboBox<String>(musicChoices);
		jcbMusic.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				if (jcbMusic.getSelectedItem().toString().equals("Sort")){
					//Do nothing LoL
				}
				else if(jcbMusic.getSelectedItem().toString().equals("Track Name")){
					musicThumbPanel.removeAll();
					srtThumbNails.sortMusicName(musicThumbPanel);
					musicThumbPanel.revalidate();
					musicThumbPanel.repaint();
				}
				else if (jcbMusic.getSelectedItem().toString().equals("Artist")){
					musicThumbPanel.removeAll();
					srtThumbNails.sortArtistName(musicThumbPanel);
					musicThumbPanel.revalidate();
					musicThumbPanel.repaint();
				}
				
			}
			
		});
		JPanel jpTypeOptions = new JPanel(new BorderLayout());
		jpTypeOptions.add(new JLabel ("Music"), BorderLayout.WEST);
		jpTypeOptions.add(jcbMusic, BorderLayout.EAST);
		musicPanel.add(jpTypeOptions, BorderLayout.NORTH);
		this.add(musicPanel);

	}
	
	/**
	 * This method will create the Panel for the Unclassified section
	 */
	private void unclassPanel(){
		JPanel unclassPanel = new JPanel(new BorderLayout());
		unclassThumbPanel = new JPanel(new FlowLayout());
		makeUnClassThumbNails();
		JScrollPane scroll = new JScrollPane(unclassThumbPanel,JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		unclassPanel.add(scroll, BorderLayout.CENTER);
		unclassPanel.add(new JLabel("Unclassified"), BorderLayout.NORTH);
		this.add(unclassPanel);

	}
	
	/**
	 * This method will create the individual thumb nails for the film category 
	 */
	private void makeFilmThumbNails(){
		for (Media media: pm.filmMatching()){
			JPanel jpIndividPanel = new JPanel(new BorderLayout());
			jpIndividPanel.add(media.getImage(), BorderLayout.NORTH);
			jpIndividPanel.add(new JLabel (pm.filmNameSeperation(media.getName())), BorderLayout.CENTER);
			jpIndividPanel.add(new JLabel(pm.filmYearReleasedSeperation(media.getName())+" - "+pm.filmDefinitionSeperation(media.getName())), BorderLayout.SOUTH);
			filmThumbPanel.add(jpIndividPanel);
			//System.out.println(pm.filmNameSeperationigThe(media.getName()));
		}
	}
	
	/**
	 * This method will create the individual thumb nails for the music category 
	 */
	private void makeMusicThumbNails(){
		for (Media media: pm.musicMatching()){
			JPanel jpIndividPanel = new JPanel(new BorderLayout());
			jpIndividPanel.add(media.getImage(), BorderLayout.NORTH);
			jpIndividPanel.add(new JLabel(pm.getMusicTitle(media.getName())), BorderLayout.CENTER);
			jpIndividPanel.add(new JLabel(pm.musicArtistsSeperation(media.getName())),BorderLayout.SOUTH);
			musicThumbPanel.add(jpIndividPanel);
		}
		
	}
	
	/**
	 * This method will create the individual thumb nails for the unclassified category 
	 */
	private void makeUnClassThumbNails(){
		for (Media media: pm.unclassMatching()){
			JPanel jpIndividPanel = new JPanel(new BorderLayout());
			jpIndividPanel.add(media.getImage(), BorderLayout.NORTH);
			jpIndividPanel.add(new JLabel(media.getName()), BorderLayout.CENTER);
			jpIndividPanel.add(new JLabel("Unclassified"),BorderLayout.SOUTH);
			unclassThumbPanel.add(jpIndividPanel);
		}
		
	}
	


	
	
}
