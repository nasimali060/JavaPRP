package nasimradhika;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import generator.Media;
import generator.MediaGenerator;
/**
 * 
 * @author Nasim
 * @author Radhika
 *
 */
public class PatternMatching {
	
	//Empty Constructor
	public PatternMatching(){
	}
	
	// The Media is generation before hand
	ArrayList<Media> MediaList = MediaGenerator.getMedia();
	
	/**
	 * In this method it will first check whether the Media matches the Pattern wanted then will add them to an
	 * ArrayList
	 * @return an ArrayList containing Media in the category Films
	 */
	protected ArrayList<Media> filmMatching(){
		ArrayList<Media> films = new ArrayList<Media>();
		for (Media media : MediaList){
			Pattern pattern = Pattern.compile("((.*)\\.(flv)|(.*)\\.(gif)|(.*)\\.(mkv)|(.*)\\.(mpg)|(.*)\\.(mov)|(.*)\\.(mpeg))");
			String mediaObject = media.getName();
			Matcher matcher = pattern.matcher(mediaObject);
			while (matcher.find()){
				films.add(media);
			}
		}
		return films;
		
	}
	
	/**
	 * In this method it will first check whether the Media matches the Pattern wanted then will add them to an
	 * ArrayList
	 * @return An ArrayList containing Media in the category Music
	 */
	protected ArrayList<Media> musicMatching(){
		ArrayList<Media> music = new ArrayList<Media>();
		for (Media media : MediaList){
			Pattern pattern = Pattern.compile("((.*)(.aiff)|(.*)(.aac)|(.*)(.aax)|(.*)(.oog)|(.*)(.wav)|(.*)(.wma))");
			String mediaObject = media.getName();
			Matcher matcher = pattern.matcher(mediaObject);
			while (matcher.find()){
				music.add(media);
			}
		}
		return music;
	}
	
	/**
	 * In this method it will check if ending of the media name contains an extension if it doesn't it will be
	 * added to the ArrayList unclassified
	 * @return An ArrayList containing unclassified media
	 */
	protected ArrayList<Media> unclassMatching(){
		ArrayList<Media> unclass = new ArrayList<Media>();
		for (Media media : MediaList){
			Pattern pattern = Pattern.compile("^[^\\.]*$");
			String mediaObject = media.getName();
			Matcher matcher = pattern.matcher(mediaObject);
			while (matcher.find()){
				unclass.add(media);
			}
		}
		return unclass;
	}
	
	/**
	 * The method will separate the media name, so that it returns only the required part of the media name
	 * @param media a String which would be the name of the media
	 * @return A string of the Media name if it matches
	 */
	protected String filmNameSeperation(String media){
		Pattern filmName = Pattern.compile("(\\w+\\s)+\\w*");
		Matcher matcher = filmName.matcher(media);
		if (matcher.find()){
			return matcher.group();
		}
		else{
			return null;
		}
	}
	
	/**
	 * The method will separate the media name, so that it returns only the required part of the media name
	 * @param media a String which would be the name of the media 
	 * @return A string of the Media name if it matches without The
	 */
	protected String filmNameSeperatingThe(String media){
		Pattern filmName = Pattern.compile("([^The\\s]\\w+\\s)+\\w*");
		Matcher matcher = filmName.matcher(media);
		if (matcher.find()){
			return matcher.group();
		}
		else{
			return null;
		}
	}
	
	/**
	 * The method will separate the media name, so that it returns only the required part of the media name
	 * @param media a String which would be the name of the media 
	 * @return  string of the Media Definition if it matches 
	 */
	protected String filmDefinitionSeperation(String media){
		Pattern definition = Pattern.compile("\\((HD, |SD, )(\\d{3}p|\\d{4}p)\\)");
		Matcher matcher = definition.matcher(media);
		if (matcher.find()){
			return matcher.group();
		}
		else{
			return null;
		}
	}
	
	/**
	 * The method will separate the media name, so that it returns only the required part of the media name
	 * @param media a String which would be the name of the media 
	 * @return string of the Media Year if it matches 
	 */
	protected String filmYearReleasedSeperation(String media){
		Pattern filmYearReleased = Pattern.compile("(\\(\\d{4}\\))");
		Matcher matcher = filmYearReleased.matcher(media);
		if (matcher.find()){
			return matcher.group();
		}
		else{
			return null;
		}
	}
	
	/**
	 * The method will separate the media name, so that it returns only the required part of the media name
	 * @param media a String which would be the name of the media
	 * @return string of the Media Title if it matches
	 */
	protected String getMusicTitle(String media){
		Pattern musicTitle = Pattern.compile("(.*)- (\\w+\\s)+\\w*");
		Matcher matcher = musicTitle.matcher(media);
		if (matcher.find()){
			return matcher.group(1);
		}
		else{
		return null;
		}
	}
	
	protected String getMusicTitleSeperatingThe(String media){
		Pattern musicTitle = Pattern.compile("([^The\\s].*)- (\\w+\\s)+\\w*");
		Matcher matcher = musicTitle.matcher(media);
		if (matcher.find()){
			return matcher.group(1);
		}
		else{
		return null;
		}
	}
	
	/**
	 * The method will separate the media name, so that it returns only the required part of the media name
	 * @param media a String which would be the name of the media
	 * @return string of the Media Artist if it matches
	 */
	protected String musicArtistsSeperation(String media){
		Pattern musician = Pattern.compile("- (\\w+\\s)+\\w*");
		Matcher matcher = musician.matcher(media);
		if (matcher.find()){
			return matcher.group();
		}
		else {
			return null;
		}
	}


}
