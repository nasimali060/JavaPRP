
public class HandshakePacket extends Packets{
	
	public HandshakePacket(Client a,AccessPoint b){
		super(a,b);
	}

	public String sourceAddress() {
		return sourceAddress;
	}

	public Object returnPassword() {
		return destinationAddress;
	}
}
