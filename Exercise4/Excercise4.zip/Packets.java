
public class Packets {
	private String destinationAddress;
	private String sourceAddress;
	
	
public Packets (Client a,AccessPoint b){
		destinationAddress = b.returnDeviceaddress();
		sourceAddress = a.returnDeviceaddress();	
	}
public Packets (AccessPoint a, Client b){
    	destinationAddress = b.returnDeviceaddress();
    	sourceAddress = a.returnDeviceaddress();
    }

public String packets(Client a, AccessPoint b){
		return a.address() + " " + b.returnDeviceaddress();
	}
	
	

}
