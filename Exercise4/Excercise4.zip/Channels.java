import java.util.ArrayList;
import java.util.HashMap;

public class Channels {
	private int no;		
    private ArrayList<Packets> packets;
    
    public Channels(int channelNo){
		no = channelNo;
    	packets = new ArrayList<Packets>();
    	
 	}
    public void addPacket (Packets packet){
    	packets.add(packet);
    
    
    }
    public String toString(){
        return "A new channel has been created";
    }	
 
}
    

    
  
   