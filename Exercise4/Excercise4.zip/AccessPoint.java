import java.util.ArrayList;

public class AccessPoint extends NetworkDevice {
	
	private ArrayList<String> Records;
	
	public AccessPoint(String a, String b){
		super(a,b);
	    ArrayList Records = new ArrayList<>();
	}
    
        public String returnPassword(){
        return password; 
      }
        public String toString(){
            return "A new AccessPoint has been made : "+address;
        }

}
