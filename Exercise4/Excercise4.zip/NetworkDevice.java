
  public class NetworkDevice {
  		
	
	protected String address;
	protected String password;
	
	
	public NetworkDevice(String a,String b){
		
		address = a;
		password = b;
		
	}
	public NetworkDevice(String a){
		address = a;
	}
	public void returnPassword(String c){
		password = c;
	}

	public String returnDeviceaddress(){
		return address;
	}
	
	
		
		
}

