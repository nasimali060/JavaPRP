import java.util.ArrayList;

import java.util.HashMap;


public class Network {
	int start;
	private HashMap<NetworkDevice,Channels> Channels;
	private Object address;
	private int Client;
        public String password;	
	public Network(int stat){
		start = stat;
		Channels = new HashMap<NetworkDevice,Channels>();
		
	}
	
	public void addAccessPointToChannel(AccessPoint one){
		System.out.println("Accesspoint been connected to channel ");
		Channels channel = new Channels(1);
		
		
	
	}
	public ArrayList<Channels> getBackChannels(){
     ArrayList<Channels> channel = new ArrayList<Channels>(Channels.values());
	         return channel;
	}


	
}
	