import java.util.ArrayList;

public class Client extends NetworkDevice{
	private AccessPoint accesspoint;
	public Client(String a, String b){
		super(a, b);
		
	}
        public String toString(){
            return "A new Client has been made with address: "+address;
        }

}
