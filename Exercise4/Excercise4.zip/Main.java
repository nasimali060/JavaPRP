public class Main {

	public static void main(String[] args) {
		AccessPoint starting = new AccessPoint("876:f3:59:7g:6c:8d","salad");
		Channels first = new Channels(1);
		Client device = new Client("Laptop","alpha");
		Network one = new Network(1);
		System.out.println(starting);
        System.out.println(first);
        System.out.println(device);
	    one.addAccessPointToChannel(starting);
	
	}
}
