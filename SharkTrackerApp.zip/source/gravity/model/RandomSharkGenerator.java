package gravity.model;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import api.jaws.Jaws;

/**
 * A class to generate a random shark name
 * @author Andhika
 * @author Nasim
 * @author Ahnaf
 * @author Usman
 *
 */
public class RandomSharkGenerator{

	//An arraylist to store all the names of the sharks
	private ArrayList<String> sharkNames;
	
	/**
	 * Constructor for the RandomSharkGenerator
	 * @param jaws
	 */
	public RandomSharkGenerator(Jaws jaws){
		sharkNames = jaws.getSharkNames();
	}
	
	/**
	 * Generates a random shark name
	 * @return a random shark name
	 */
	public String generateRandomShark(){
		
		//A variable of type int to store the number of names of sharks
		int size = sharkNames.size();
		
		//A variable of type int that is generated randomly from 0 to 'size'
		int randomNumber = new Random().nextInt(size);
		
		//Get the name of the shark from the array list at index 'randomNumber'
		String randomSharkName = sharkNames.get(randomNumber);
		
		//Create the format for dates
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY HH:mm:ss");
		
		//A variable of type String to store the date at present time
		String currentDate = dateFormat.format(new Date());
		
		try {
			
			//An object to output text to a text file
			BufferedWriter writer = new BufferedWriter(new FileWriter("data/SharkOfTheDay.txt"));
			
			//Writes the random shark name and the date when it was generated into the specified text file
			writer.write(randomSharkName + "_" + currentDate);
			
			//Close the writer
			writer.close();	
		
		
		} catch (IOException e) {
			System.out.println("Error with specified file");
		}
		
		//Return the random shark name
		return randomSharkName;
	}	
		
}
