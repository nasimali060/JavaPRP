package gravity.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeMap;
import api.jaws.Jaws;
import api.jaws.Ping;
import api.jaws.Shark;

/**
 * This class is used as a search function, so when the user will press search in the Search frame,
 * this class will be used to filter and return the sharks to the user.
 * 
 * @author Nasim
 * @author Andhika
 * @author Ahnaf
 * @author Usman
 *
 */

public class Search {

	private ArrayList<Ping> sharkPings;
	private HashSet <String> sharkNames; 
	private ArrayList <Shark> sharkObjects;
	private TreeMap<String, Shark> finalSharkResults;
	private String trackingRangeInput;
	private String genderInput;
	private String stageOfLifeInput;
	private String tagLocationInput;
	private Jaws jaws;
	private LatestPingGenerator ping;
	
	/**
	 * The constructor to the Search method
	 * 
	 * @param jaws
	 */
	public Search(Jaws jaws,LatestPingGenerator ping){
		
		this.jaws = jaws;
		
		this.ping = ping;
	
	}

	/**
	 * A method that will set the ArrayList to specified time range of sharks this will be dependent on users 
	 * choice
	 */
	public void searchTimeRange(){
		
		if(trackingRangeInput.equals("Past 24 Hours")){
			sharkPings = jaws.past24Hours();
		}
		
		else if(trackingRangeInput.equals("Past Week")){
			sharkPings = jaws.pastWeek();
		}
		
		else if(trackingRangeInput.equals("Past Month")){
			sharkPings = ping.getPastMonth();
		}
		
	}
	
	/**
	 * A method to store in a ArrayList unique sharks 
	 */
	public void removeDuplicates(){
		
		sharkNames = new HashSet<>();
		
		sharkObjects = new ArrayList<>();
		
		// First for loop will remove duplicate names by storing them in a HashSet
		for (Ping ping: sharkPings){
		
			sharkNames.add(ping.getName());
		
		}
		
		// Second for loop will get the shark objects once the names are removed
		for (String sharkName: sharkNames){
			sharkObjects.add(jaws.getShark(sharkName));
		}
		
	}
	
	/**
	 * A method to filter the sharks based on user choices made in the search panel Combo Boxes
	 * simple if and else condition statements are used to get the sharks wanted
	 */
	public void filter(){
		
		/*
		 * A TreeMap automatically sorts the keys in order from smallest to biggest, by collections we are
		 * reversing order so that the latest shark ping is stored first 
		 */
		finalSharkResults = new TreeMap<>(Collections.reverseOrder());
		
		/*
		 *  For loop iteration to go through all sharks in the list and if else conditions to filter results
		 *  based on user choices
		 */
		for(Shark shark: sharkObjects){
			checkGender(shark,genderInput,stageOfLifeInput,tagLocationInput);
		}
	
	}
	
	/**
	 * A method that will check the gender input
	 * 
	 * @param shark An shark object that will be checked upon
	 * @param genderInput A selected String the user chooses in the search panel combo boxes
	 * @param solInput A selected String the user chooses in the search panel combo boxes
	 * @param tagInput A selected String the user chooses in the search panel combo boxes
	 */
	private void checkGender(Shark shark, String genderInput, String solInput, String tagInput){
		
		if (shark.getGender().equals(genderInput)){
			checkStageOfLife(shark, solInput, tagInput);
		}
		else if (genderInput.equals("All")){
			checkStageOfLife(shark,solInput, tagInput);
		}
	}
	
	/**
	 * A method that will check the stage of life input based on the current shark checked upon
	 * 
	 * @param shark An shark object that will be checked upon
	 * @param solInput A selected String the user chooses in the search panel combo boxes
	 * @param tagInput A selected String the user chooses in the search panel combo boxes
	 */
	private void checkStageOfLife(Shark shark,String solInput, String tagInput){
		
		if (shark.getStageOfLife().equals(solInput)){
			checkTagLocation(shark, tagInput);
		}
		else if (solInput.equals("All")){
			checkTagLocation(shark, tagInput);
		}
	}
	
	/**
	 * A method that will check the tag location input based on the current shark
	 * 
	 * @param shark An shark object that will be checked upon
	 * @param tagInput A selected String the user chooses in the search panel combo boxes
	 */
	private void checkTagLocation(Shark shark, String tagInput){
		
		if (shark.getTagLocation().equals(tagInput)){
			finalSharkResults.put(ping.getLatestDate(shark.getName()), shark);
		}
		else if (tagInput.equals("All")){
			finalSharkResults.put(ping.getLatestDate(shark.getName()), shark);
		}
	}
	
	/**
	 * A method to set the Tracking range input
	 *  
	 * @param trackingRangeInput A user selected combo box string from the Search frame class
	 */
	public void setTrackingRangeInput(String trackingRangeInput){
			
		this.trackingRangeInput = trackingRangeInput;
	
	}
	
	/**
	 * A method to set the Gender wanted input
	 * 
	 * @param genderInput A user selected combo box string from the Search frame class
	 */
	public void setGenderInput(String genderInput){
	
		this.genderInput = genderInput;
	
	}
	
	/**
	 * A method to set the Stage of Life wanted input
	 * 
	 * @param stageOfLifeInput A user selected combo box string from the Search frame class
	 */
	public void setStageOfLifeInput(String stageOfLifeInput){
		
		this.stageOfLifeInput = stageOfLifeInput;
	
	}
	
	/**
	 * A method to set the Tag Location wanted input
	 * 
	 * @param tagLocationInput A user selected combo box string from the Search frame class
	 */
	public void setTagLocationInput(String tagLocationInput){
		
		this.tagLocationInput = tagLocationInput;
	
	}
	
	/**
	 * A return method to get the final sharks wanted in a Tree Map, with each shark matched to their Pings
	 * 
	 * @return An TreeMap containing sharks mapped to their ping times
	 */
	public TreeMap<String, Shark> getFinalResults(){
		
		return (TreeMap<String, Shark>) finalSharkResults;
	
	}
	
}
