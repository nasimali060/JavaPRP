package gravity.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

import api.jaws.Jaws;
import api.jaws.Ping;
import api.jaws.Shark;

/**
 * In this class, the data for the Pie Charts will be created which will be dependent on the users choices made
 * on the Search Panel combo boxes, this class only creates the data, and then will be passed to the controller
 * so that the data will be turned into charts and displayed in the frames
 * 
 * @author Nasim
 *
 */
public class StatisticsData {
		
	private Jaws jaws;
	private ArrayList <Shark> uniqueSharks;
	private ArrayList <Shark> wantedSOLSharks;
	private ArrayList <Shark> wantedTLSharks;
	private LatestPingGenerator ping;
	
	/**
	 * The constructor for the model of the Statistics data class
	 * @param jaws An Jaws object from the API Jaws
	 */
	public StatisticsData(Jaws jaws, LatestPingGenerator ping){
		this.jaws = jaws;
		this.ping = ping;
	}
	
	/**
	 * In this method depending on which time range the user selects will get all the pings 
	 * and remove duplicate sharks and store the shark object in the uniqueSharks arraylist
	 * 
	 * @param input This will be the time range that will be selected in the search panel
	 * @return An ArrayList containing unique sharks in the specified time range the user selects
	 */
	private ArrayList<Shark> uniqueSharks(String input){
		ArrayList <Ping> timeRange;
		//Condition will get a certain set of pings based on user choice
		if (input.equals("Past 24 Hours")){
			 timeRange = jaws.past24Hours();
		}
		else if (input.equals("Past Week")){
			timeRange = jaws.pastWeek();
		}
		else {
			timeRange = ping.getPastMonth();
		}
		
		HashSet<String>removeDuplicates = new HashSet<>();
		
		uniqueSharks = new ArrayList<>();
		
		//Will remove duplicate names using HashSet
		for (Ping ping : timeRange){
			removeDuplicates.add(ping.getName());
		}
		
		for (String name: removeDuplicates){
			uniqueSharks.add(jaws.getShark(name));
		}
 		
		return uniqueSharks;
		
	}
	
	/**
	 * In this method it will store in an arraylist the wanted stage of life sharks so that will be 
	 * returned for data use when creating the pie charts
	 * 
	 * @param input This will be the stage of life range that will be selected in the search panel
	 * @return An ArrayList containing the wanted sharks in the specified stage of life range the 
	 * user selects
	 */
	private ArrayList<Shark> stageOfLifeSharks(String input){
		wantedSOLSharks = new ArrayList<>();
		
			for (Shark shark: uniqueSharks){
				 if (shark.getStageOfLife().equals(input)){
					 wantedSOLSharks.add(shark);
				 }
				 else if (input.equals("All")){
					 wantedSOLSharks.add(shark);
				 }
			}
		return wantedSOLSharks;	
	}
	
	/**
	 * In this method it will store in an arraylist the wanted tag location sharks so that will be 
	 * returned for data use when creating the pie charts
	 * 
	 * @param input This will be the tag location range that will be selected in the search panel
	 * @return An ArrayList containing the wanted sharks in the specified tag location range the 
	 * user selects
	 */
	private ArrayList<Shark> tagLocatedSharks(String input){
		 wantedTLSharks = new ArrayList<>();
			for (Shark shark: uniqueSharks){
				 if (shark.getTagLocation().equals(input)){
					 wantedTLSharks.add(shark);
				 }
				 else if (input.equals("All")){
					 wantedTLSharks.add(shark);
				 }
			}
		return wantedTLSharks;
	}
	
	/**
	 * This method will construct the data that will be used to create the Pie Charts, this will be done
	 * by sorting them to arraylists and using some objects from the JCOMMON API and the JFREECHART API
	 * 
	 * @param input This will be the stage of life range that will be selected in the search panel
	 * @return An PieDataset which will be used as the data to construct the Pie Charts
	 */
	 private PieDataset createStageOfLifeDataset(String input) {
		 ArrayList<Shark> sharkData =stageOfLifeSharks(input);
		 ArrayList <Shark> matureSharks = new ArrayList<>();
		 ArrayList <Shark> immatureSharks = new ArrayList<>();
		 ArrayList <Shark> undeterminedSharks = new ArrayList<>();
		 for (Shark shark: sharkData){
			 if (shark.getStageOfLife().equals("Mature")){
				  matureSharks.add(shark);
			 }
			 else if (shark.getStageOfLife().equals("Immature")){
				  immatureSharks.add(shark);
			 }
			 else if (shark.getStageOfLife().equals("Undetermined")){
				  undeterminedSharks.add(shark);
			 }
		 }
		 DefaultPieDataset dataset = new DefaultPieDataset();
		 if (matureSharks.size()>0){
			  dataset.setValue( "Mature Sharks" , matureSharks.size());  
		 } 
		 if (immatureSharks.size()>0){
			  dataset.setValue( "Immature Sharks", immatureSharks.size() ); 
		 }
		 if (undeterminedSharks.size()>0){
			  dataset.setValue( "Undetermined Sharks", undeterminedSharks.size() ); 
		 }
		 return dataset;
	 }
	 
	 /**
	  * This method will construct the data that will be used to create the Pie Charts, this will be done
	  * by sorting them to arraylists and using some objects from the JCOMMON API and the JFREECHART API
	  * 
	  * @param input This will be the time range that will be selected in the search panel
	  * @return An PieDataset which will be used as the data to construct the Pie Charts
	  */
	 private PieDataset createUniqueGenderedDataset(String input) {
		 ArrayList<Shark> sharkData = uniqueSharks(input);
		 ArrayList <Shark> maleSharks = new ArrayList<>();
		 ArrayList <Shark> femaleSharks = new ArrayList<>();
		 for (Shark shark: sharkData){
			 if (shark.getGender().equals("Male")){
				 maleSharks.add(shark);
			 }
			 else {
				 femaleSharks.add(shark);
			 }
		}
		  
	    DefaultPieDataset dataset = new DefaultPieDataset();
	    if (maleSharks.size()>0){
	    	  dataset.setValue( "Male Sharks" , maleSharks.size());  
	    }
	    if (femaleSharks.size()>0){
	    	  dataset.setValue( "Female Sharks", femaleSharks.size() );   
	    }
	    return dataset;         
	    }
	   
	 /**
	  * This method will construct the data that will be used to create the Pie Charts, this will be done
	  * by sorting them to arraylists and using some objects from the JCOMMON API and the JFREECHART API
	  * 
	  * @param input This will be the tag location range that will be selected in the search panel
	  * @return An PieDataset which will be used as the data to construct the Pie Charts
	  */
	  private PieDataset dataForTagLocation(String input){
		 ArrayList<Shark> sharkData = tagLocatedSharks(input);
		 ConcurrentHashMap <String, ArrayList<Shark>> tagLocation = new ConcurrentHashMap <String, ArrayList<Shark>> ();
		 for (Shark shark: sharkData){
			 if (tagLocation.containsKey(shark.getTagLocation())){
				   tagLocation.get(shark.getTagLocation()).add(shark);
			 }else{
				   ArrayList<Shark> values = new ArrayList<Shark>();
				   values.add(shark);
				   tagLocation.put(shark.getTagLocation(), values);
			 }
		 }
 		   
		 DefaultPieDataset dataset = new DefaultPieDataset( );
		  for (String tag: tagLocation.keySet()){
			  dataset.setValue(tag, tagLocation.get(tag).size());
		  }
		  return dataset;
	   }
	   
	  /**
	   * This return method will construct the charts using the PieDataSet returns
	   * 
	   * @param input This will be the time range that will be selected in the search panel
	   * @return The constructed Pie chart that was created using the required data set 
	   */
	  public JFreeChart createGenderedChart(String input){
	    JFreeChart chart = ChartFactory.createPieChart(      
	       "Gendered Sharks",  // Title of the chart
	        createUniqueGenderedDataset(input),  // Data that we want in the chart  
	        true,true,false);
	      return chart;
	   }
	   
	  /**
	   * This return method will construct the charts using the PieDataSet returns
	   * 
	   * @param input This will be the stage of life range that will be selected in the search panel
	   * @return The constructed Pie chart that was created using the required data set
	   */
	   public JFreeChart createStageOfLifeChart(String input){
		      JFreeChart chart = ChartFactory.createPieChart(      
		        "Stage Of Life Sharks",  //  Title of the chart
		        createStageOfLifeDataset(input),  //  Data that we want in the chart  
		        true,true,false);
		      return chart;
		   }
	   
	   /**
	    * This return method will construct the charts using the PieDataSet returns
	    * 
	    * @param input This will be the tag location range that will be selected in the search panel
	    * @return The constructed Pie chart that was created using the required data set
	    */
	   public JFreeChart createTagLocationChart(String input){
		      JFreeChart chart = ChartFactory.createPieChart(      
		         "Tag Located Sharks",  // Title of the chart
		         dataForTagLocation(input), // Data that we want in the chart    
		         true,true,false);
		      return chart;
		   }
	   
	   /**
	    * This method will cast the charts to an JPanel, so that it can be added to an JFrame or JPanel
	    * 
	    * @param chart An chart object
	    * @return An JPanel that will be an PieChart
	    */
	   public JPanel getChartPanel(JFreeChart chart){
		   return new ChartPanel(chart);
	   }
	   
	   /**
	    * A return method to get the ArrayList containing Tag Located sharks
	    * 
	    * @return an ArrayList containing a specified tagLocated sharks or all sharks depending on users 
	    * choice
	    */
	   public ArrayList<Shark> getwantedTLSharks(){
		   return wantedTLSharks;
	   }
	   
	   /**
	    * A return method to get the ArrayList containing Stage of Life sharks
	    * 
	    * @return an ArrayList containing a specified stage Of life sharks or all sharks depending on users 
	    * choice
	    */
	   public ArrayList<Shark> getwantedSOLSharks(){
		   return wantedSOLSharks;
	   }
	   
	   /**
	    * A return method to get the ArrayList containing unique sharks
	    * 
	    * @return an ArrayList containing a unique sharks 
	    */
	   public ArrayList<Shark> getUniqueSharks(){
		   return uniqueSharks;
	   }

}
