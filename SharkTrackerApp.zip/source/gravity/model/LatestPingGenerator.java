package gravity.model;

import java.util.ArrayList;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import api.jaws.Jaws;
import api.jaws.Ping;

/**
 * This class will be used to get the latest ping of the sharks and use this to display in the search frame panel
 * in the Search frame right panel where the shark information is displayed. In this class there is a method that
 * allows to search for a ping based upon the sharks name.
 * 
 * @author Nasim
 * @author Andhika
 * @author Ahnaf
 * @author Usman
 *
 */
public class LatestPingGenerator {
	private Jaws jaws;
	private ConcurrentHashMap<String, String> duplicatesRemoved;
	private ArrayList<Ping> sharkPings;
	
	/**
	 * The constructor takes an Jaws object and retrieves the Ping dates for sharks through the createFunction()
	 * method
	 * 
	 * @param jaws
	 */
	public LatestPingGenerator(Jaws jaws){
		this.jaws = jaws;
		createFunction();
	}
	
	/**
	 * This method gets the Pings from past month then maps the lastest ping to the shark names
	 */
	private void createFunction() {
		 sharkPings = jaws.pastMonth();
		TreeMap <String, String>sortSharks = new TreeMap<>();
		duplicatesRemoved = new ConcurrentHashMap<>();
		for (Ping ping: sharkPings){
			sortSharks.put(ping.getTime(), ping.getName());
		}
		for (String date: sortSharks.keySet()){
			duplicatesRemoved.put(sortSharks.get(date), date);
		}
		
	}
	
	/**
	 * A return method to get the pastMonth Pings which will be used in the search method
	 * 
	 * @return an ArrayList containing pings of past month
	 */
	protected ArrayList<Ping> getPastMonth(){
		return sharkPings;
	}
	
	/**
	 * This return method will retrieve the latest ping from the duplicatesRemoved Hash Map, this method will
	 * be used to search for latest pings for sharks in the favourites list
	 * 
	 * @param name The name of the shark that you want the latest Ping
	 * @return A String that will be the latest ping of the shark
	 */
	public String getLatestDate (String name){
		return duplicatesRemoved.get(name);
	}

}
