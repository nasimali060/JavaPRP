package gravity.controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingWorker;

import api.jaws.Jaws;
import gravity.model.*;
import gravity.view.*;

/**
 * A class which acts as a controller between the view and the model of the SearchTracker application
 * @author Andhika
 * @author Nasim
 * @author Ahnaf
 * @author Usman
 */
public class Controller{
	
	private Jaws jaws;
	private StartFrame startFrame;
	private SearchFrame searchFrame;
	private FavouritesFrame favouritesFrame;
	private UserProfile userDialog;
	private Login loginDialog;
	private Search search;
	private FavouritesMapFrame favouritesMapFrame;
	private StatisticsData chartDatas;
	File users = new File("source/data/Users.txt");

	/**
	 * Constructor for the Controller class
	 * @param jaws
	 * @param chartDatas
	 * @param startFrame
	 * @param searchFrame
	 * @param favouritesFrame
	 * @param userDialog
	 * @param loginDialog
	 * @param search
	 * @param favouritesMapFrame
	 * @throws IOException
	 */
	public Controller(Jaws jaws, StatisticsData chartDatas, StartFrame startFrame, SearchFrame searchFrame, FavouritesFrame favouritesFrame, UserProfile userDialog, Login loginDialog, Search search,FavouritesMapFrame favouritesMapFrame) throws IOException{
		
		this.jaws = jaws;
		this.startFrame = startFrame;
		this.searchFrame = searchFrame;
		this.jaws = jaws;
		this.startFrame = startFrame;
		this.searchFrame = searchFrame;
		this.favouritesFrame = favouritesFrame;
		this.userDialog = userDialog;
		this.loginDialog = loginDialog;
		this.search = search;
		this.favouritesMapFrame = favouritesMapFrame;
		this.chartDatas = chartDatas;
		
		startFrame.addController(new StartFrameListener());
		searchFrame.addController(new SearchFrameListener());
		favouritesFrame.addMapController(new FavouritesFrameListener());
		userDialog.addController(new UserProfileListener());
		
	}
	
	/**
	 * Starts the program by opening the StartFrame
	 * @param condition
	 */
	public void startProgram(boolean condition){
		startFrame.setVisible(condition);
	}
	
	/**
	 * Inner classes which acts as the StartFrame ActionListener
	 *
	 */
	private class StartFrameListener implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent event) {
			
			if(event.getActionCommand().equals("Search")){
				
				searchFrame.getRightPanel().removeAll();
				searchFrame.setVisible(true);
				startFrame.setVisible(false);
			
			}

			else if(event.getActionCommand().equals("Favourites")){
				
				favouritesFrame.setVisible(true);
				favouritesFrame.setFollowedSharks(searchFrame.getFollowedSharks());
				favouritesFrame.createFavouritesList();
				startFrame.setVisible(false);
			}
			
			else if(event.getActionCommand().equals("Sign-Up")){
				userDialog.setVisible(true);
			}
			
			else if(event.getActionCommand().equals("Login")){
				loginDialog.setVisible(true);
			}
		}
		
	};
	
	/**
	 * 
	 * Inner classes which acts as the SearchFrame ActionListener
	 *
	 */
	private class SearchFrameListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event){
			
			
			if(event.getActionCommand().equals("Search")){
				
				searchFrame.getRightPanel().removeAll();
				searchFrame.getRightPanel().repaint();
				searchFrame.getRightPanel().revalidate();
				
				search.setTrackingRangeInput(searchFrame.getTrackingRangeInput());
				search.setTagLocationInput(searchFrame.getTagLocationInput());
				search.setGenderInput(searchFrame.getGenderInput());
				search.setStageOfLifeInput(searchFrame.getStageOfLifeInput());
				
				new SearchWorker().execute();
				
			}
			else if (event.getActionCommand().equals("Statistics")){
				
				StatisticsFrame dataFrame = new StatisticsFrame();
				
				dataFrame.getGenderedChart().add(chartDatas.getChartPanel(chartDatas.createGenderedChart(searchFrame.getTrackingRangeInput())));
				if (chartDatas.getUniqueSharks().isEmpty()){
					JLabel jlNoResults = new JLabel("No Sharks in this set!");
					jlNoResults.setFont(new Font("Trebuchet MS", Font.BOLD, 30));
				    dataFrame.getGenderedChart().removeAll();
					dataFrame.getGenderedChart().add(jlNoResults);
				}
				dataFrame.getStageOfLifeChart().add(chartDatas.getChartPanel(chartDatas.createStageOfLifeChart(searchFrame.getStageOfLifeInput())));
				if (chartDatas.getwantedSOLSharks().isEmpty()){
					JLabel jlNoResults = new JLabel("No Sharks in this set!");
					jlNoResults.setFont(new Font("Trebuchet MS", Font.BOLD, 30));
					dataFrame.getStageOfLifeChart().removeAll();
					dataFrame.getStageOfLifeChart().add(jlNoResults);
				}
				dataFrame.getTagLocatedChart().add(chartDatas.getChartPanel(chartDatas.createTagLocationChart(searchFrame.getTagLocationInput())));
				if (chartDatas.getwantedTLSharks().isEmpty()){
					JLabel jlNoResults = new JLabel("No Sharks in this set!");
					jlNoResults.setFont(new Font("Trebuchet MS", Font.BOLD, 30));
					dataFrame.getTagLocatedChart().removeAll();
				    dataFrame.getTagLocatedChart().add(jlNoResults);
				}
				dataFrame.setVisible(true);
			} else if (event.getActionCommand().equals("Go Back")){
				searchFrame.setVisible(false);;
				startFrame.setVisible(true);
			}
			
		}

	};
	
	/**
	 * Inner class to create a loading screen for the SearchFrame
	 *
	 */
	private class SearchWorker extends SwingWorker<Void, Void>{

		/**
		 * Constructor for the SearchWorker
		 */
		public SearchWorker() {
			
			JPanel jpLoading = new JPanel(new GridLayout(2, 1));
			JPanel jpLoadingSearch = new JPanel(new FlowLayout(FlowLayout.CENTER));
			JLabel jlLoading = new JLabel("LOADING SEARCH...");
			
			jlLoading.setFont(new Font("Trebuchet MS", Font.BOLD, 40));
			jlLoading.setForeground(Color.BLACK);
			jpLoading.add(new JLabel(new ImageIcon("images/shark2.gif")), BorderLayout.CENTER);
			jpLoadingSearch.add(jlLoading);
			jpLoading.add(jpLoadingSearch);
			
			searchFrame.getRightPanel().add(jpLoading);
			searchFrame.setTitle("Loading...");
		
		}
		
		/**
		 * Do all the prolonged searches in the background of the thread
		 */
		@Override
		protected Void doInBackground() throws Exception {
			
			search.searchTimeRange();
			search.removeDuplicates();
			search.filter();
			searchFrame.setSearchResults(search.getFinalResults());
			
			return null;
		}
		
		/**
		 * Sets the result of the search to the rightPanel of the SearchFrame
		 * once it is done.
		 * @see SearchFrame class
		 */
		@Override
		protected void done() {
			
			searchFrame.setTitle("Search"); 
			searchFrame.getRightPanel().removeAll();
			searchFrame.getRightPanel().revalidate();
			searchFrame.getRightPanel().repaint();
			searchFrame.createRightPanel();
		
		}
		
	};
	
	/**
	 * Inner class which acts the FavouriteFrame ActionListener and MouseListener
	 *
	 */
	private class FavouritesFrameListener implements MouseListener, ActionListener{

		/**
		 * Clears the rightPanel of the searchFrame upon a click in the favourite list
		 */
		@Override
		public void mouseClicked(MouseEvent mouseEvent) {
			
			searchFrame.getRightPanel().removeAll();
			searchFrame.getRightPanel().repaint();
			searchFrame.getRightPanel().revalidate();
			
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {}

		@Override
		public void mouseExited(MouseEvent arg0) {}

		@Override
		public void mousePressed(MouseEvent arg0) {}

		@Override
		public void mouseReleased(MouseEvent arg0) {}
		
		@Override
		public void actionPerformed(ActionEvent e) {			
			
			if(e.getActionCommand().equals("Favourite Sharks on Map!")){
				HashSet<String> sharkLocation = favouritesFrame.getFollowedSharks();

				favouritesMapFrame.generatePredefinedURL();
				
				try {
					favouritesMapFrame.generateNewURL();
				} catch (MalformedURLException e1) {
					
					e1.printStackTrace();
				}
					
				for (String newSharkLocation: sharkLocation){
					
					double latitude= jaws.getLastLocation(newSharkLocation).getLatitude();
					double longitute = jaws.getLastLocation(newSharkLocation).getLongitude();
					favouritesMapFrame.createMarkersOnMap(latitude,longitute);

				}
				try {
					favouritesMapFrame.displayMap();
				} 
				catch (MalformedURLException e1) {
					e1.printStackTrace();
				}
				favouritesMapFrame.setVisible(true);
				favouritesFrame.setVisible(false);
				favouritesMapFrame.addMapController(new MapListener());
			
		
			}
			else if(e.getActionCommand().equals("Go Back")){
				favouritesFrame.dispose();
				startFrame.setVisible(true);
			
			}}
		};
	
	private class UserProfileListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event) {
			
			JButton buttonClicked = (JButton) event.getSource();
			if(buttonClicked.getActionCommand().equals("Submit")){
				
				String line = null;
				String temp = "";
				String username = null;
				String usernameInput = userDialog.getInput();
				String passwordInput = userDialog.getPassword();
				
				try {
					FileReader 	fr = new FileReader(users);
					BufferedReader br = new BufferedReader(fr);
					
					while((line = br.readLine()) != null) {
						username = line.substring(0,line.lastIndexOf(":"));
						if(username.equals(usernameInput)){	
							temp = username;
							JOptionPane.showMessageDialog(null,"UserName Already Taken!", "Error",
	                                  JOptionPane.ERROR_MESSAGE);
							break;
						}
											
					}br.close();
					
					if(!temp.equals(usernameInput)){
					try {								
						FileWriter	fw = new FileWriter(users, true);
						BufferedWriter bw = new BufferedWriter(fw);
						bw.newLine();
						bw.write(usernameInput   + ":" + passwordInput);
						bw.close();
						}
						catch (IOException e) {
							e.printStackTrace();
						}	
					}
				}
				
				catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
	   
				userDialog.dispose();
				userDialog.getTextField().setText("");
				userDialog.getPasswordField().setText("");
			}	
		}
	};
	
	private class LoginListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event) {
			JButton buttonClicked = (JButton) event.getSource();
			if(buttonClicked.getActionCommand().equals("Login")){
				
				String line = null;
				
				try {
					FileReader fr = new FileReader(users);
					BufferedReader br = new BufferedReader(fr);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				
			}
		}
		
	}
	
	
	private class MapListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			favouritesMapFrame.dispose();
			favouritesFrame.setVisible(true);
			
		}
	}
		
}
	

