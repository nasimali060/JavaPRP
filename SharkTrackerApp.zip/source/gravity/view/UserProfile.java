package gravity.view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
/**
 * A Class that will load the UserProfile diagloq
 * 
 * @author Andhika
 * @author Nasim
 * @author Ahnaf
 * @author Usman
 *
 */
public class UserProfile extends JDialog {

	
	private static final long serialVersionUID = 8048783399524142495L;
	
	JTextField inputName;
	JButton submitButton;
	JPasswordField passwordField;

	/**
	 * Constructs a dialog window prompting the user to signup.
	 */
	public UserProfile() {

		setTitle("Login");
		setSize(300,250);
		setLayout(new GridLayout(3,2));
		addWidgets();
		ImageIcon icon = new ImageIcon("images/sharkIcon.png");
		setIconImage(icon.getImage());
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setResizable(false);
	}

	/**
	 * Creates the components required for the dialog window.
	 */
	public void addWidgets() {

		JLabel name = new JLabel("Enter Name: ");
		name.setFont(new Font("Courier New", Font.ITALIC, 14));
		this.add(name);
		
		inputName = new JTextField();
		inputName.setPreferredSize(new Dimension(30,30));
		this.add(inputName);
		
		JLabel password = new JLabel("Enter Password: ");
		password.setFont(new Font("Courier New", Font.ITALIC, 14));
		this.add(password);
		
		passwordField = new JPasswordField();
		passwordField.setPreferredSize(new Dimension(30,30));
		this.add(passwordField);

		submitButton = new JButton("Submit");
		this.add(submitButton);
	}
	
	/**
	 * @return the JTextField.
	 */
	public JTextField getTextField() {
		return inputName;
	}
	
	/**
	 * @return the username typed.
	 */
	public String getInput() {
		return inputName.getText();
	}

	/**
	 * @return the JPasswordField.
	 */
	public JPasswordField getPasswordField() {
		return passwordField;
	}
	
	/**
	 * @return the password typed.
	 */
	@SuppressWarnings("deprecation")
	public String getPassword() {
		return passwordField.getText();
	}
	
	/**
	 * @param controller
	 */
	public void addController(ActionListener controller) {
		submitButton.addActionListener(controller);
	}

}