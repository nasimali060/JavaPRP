package gravity.view;

import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
/**
 * This class only creates the frame of the Statistics, which will display the Pie charts, it will get the data
 * of the pie charts through the controller from the StatisticsData class.
 * 
 * @author Nasim
 *
 */
public class StatisticsFrame extends JFrame {
	
	private static final long serialVersionUID = -7399385904947806569L;
	private JPanel genderedChart;
	private JPanel stageOfLifeChart;
	private JPanel tagLocatedChart;
	private JPanel mainCharts;
	
	/**
	 * The constructor of the Statistics frame so that when the object is created the object will properly
	 * be constructed
	 */
	public StatisticsFrame(){
		super("Statistics");
		setSize(1000,500);
		ImageIcon icon = new ImageIcon("images/sharkIcon.png");
		setIconImage(icon.getImage());
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		createWidgets();
		}
	
	/**
	 * In this method three panels are created and placed into the JFrame, the three panels will be the 
	 * place holders for the three pie charts that will be added. A scroll pane was added so that the main
	 * JFrame panel will be scrollable 
	 */
	private void createWidgets() {
		mainCharts = new JPanel(new GridLayout(1,3));
		genderedChart = new JPanel();
		stageOfLifeChart = new JPanel();
		tagLocatedChart = new JPanel();
		mainCharts.add(genderedChart);
		mainCharts.add(stageOfLifeChart);
		mainCharts.add(tagLocatedChart);
		JScrollPane scroll = new JScrollPane(mainCharts);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		add(scroll);
	}
	
	/**
	 * A return method to get the gendered Panel
	 * @return an JPanel object
	 */
	public JPanel getGenderedChart(){
		return genderedChart;
	}
	
	/**
	 * A return method to get the stage of life Panel
	 * @return an JPanel object
	 */
	public JPanel getStageOfLifeChart(){
		return stageOfLifeChart;
	}
	
	/**
	 * A return method to get the tag location of sharks Panel
	 * @return an JPanel object
	 */
	public JPanel getTagLocatedChart(){
		return tagLocatedChart;
	}
	
	/**
	 * A return method to get the main Panel where the three other panels will be placed into
	 * @return an JPanel object
	 */
	public JPanel getMainCharts(){
		return mainCharts;
	}
	

}
