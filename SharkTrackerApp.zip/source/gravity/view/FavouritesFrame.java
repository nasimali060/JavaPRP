package gravity.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import api.jaws.Jaws;
import api.jaws.Shark;
import gravity.controller.*;
import gravity.model.*;
import api.jaws.Location;

/**
 * A class to display the list of sharks the user has followed
 * 
 * @author Usman
 * @author Nasim
 * @author Andhika
 * @author Ahnaf
 *
 */
public class FavouritesFrame extends JFrame{
	
	private static final long serialVersionUID = -4603689865706099368L;
	private Set<String> followedSharks;
	private Map<Double, Shark> sortedSharksDistance;
	private JPanel jpCenter;
	private SearchFrame searchFrame;
	private Jaws jaws;
	private LatestPingGenerator getPing;
	private JButton jbFavMap;
	private JButton jbGoBack;
	private JPanel jpSouth;
	private  String onLand;
	private LatestPingGenerator ping;
	
	/**
	 * Constructor for the FavouritesFrame
	 * @param jaws
	 * @param searchFrame
	 * @param ping
	 */
	public FavouritesFrame(Jaws jaws, SearchFrame searchFrame, LatestPingGenerator ping) {
		
		super("Favourites");
		
		this.searchFrame = searchFrame;
		this.jaws = jaws;
		this.ping = ping;
		followedSharks = new HashSet<String>();
		sortedSharksDistance = new TreeMap<Double, Shark>();
		getPing = new LatestPingGenerator(jaws);
		setLayout(new BorderLayout());
		setSize(500,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon icon = new ImageIcon("images/sharkIcon.png");
		setIconImage(icon.getImage());
		addWidgets();
		//readStoredFollowedSharks("source/data/FavouriteSharks.txt");
	}

	/**
	 * Adds most of the components that make up the FavouritesFrame
	 */
	private void addWidgets() {
		
		JPanel jpFrame = new JPanel(new BorderLayout());
		jpFrame.setBorder(BorderFactory.createEmptyBorder(10, 5, 5, 5));
		JPanel jpMainCenter = new JPanel(new BorderLayout());
		jpCenter =  new JPanel();
		jpCenter.setLayout(new BoxLayout(jpCenter, BoxLayout.Y_AXIS));
		jpCenter.setPreferredSize(new Dimension(400,300));
		jpCenter.setBackground(Color.WHITE);
		//jpMainCenter.add(jpCenterLed)
		
		jpFrame.add(new JLabel("Your favourite sharks are this far away from you right now: "), BorderLayout.NORTH);
		jpFrame.add(jpCenter, BorderLayout.CENTER);
		
		add(jpFrame, BorderLayout.CENTER);
		jbFavMap = new JButton("Favourite Sharks on Map!");
		jbGoBack = new JButton("Go Back");
		jpSouth = new JPanel(new FlowLayout());
		jpSouth.add(jbGoBack);
		jpSouth.add(jbFavMap);
		jpFrame.add(jpSouth,BorderLayout.SOUTH);
	}
	
	/**
	 * Creates the list of followed sharks
	 * @see sortFollowedSharks
	 * @see createSharksLabel
	 */
	public void createFavouritesList() {
		
		jpCenter.removeAll();
		jpCenter.repaint();
		jpCenter.revalidate();
		sortedSharksDistance.clear();
		//followedSharks.clear();
		
		//readStoredFollowedSharks("src/FavouriteSharks.txt");
		sortFollowedSharks();
		createSharksLabel();
		this.repaint();
		this.revalidate();
		
	}
	
	/**
	 * Create the label for each individual shark in the FavouritesFrame
	 */
	private void createSharksLabel(){
		
		if(!sortedSharksDistance.isEmpty()){
			for (Double distance: sortedSharksDistance.keySet()){
				//String name = sortedSharksDistance.get(distance).toString();
				//System.out.println(name);
				JLabel jlFavouriteShark = new JLabel();
				jlFavouriteShark.setText(sortedSharksDistance.get(distance) + ": " + distance + " miles" + " "+ sharkNado(sortedSharksDistance.get(distance).toString()));// + //controller.sharkNado());
				jlFavouriteShark.addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						if (searchFrame.getFinalResults()==null){
							searchFrame.setfinalResultsPanel();
							searchFrame.getRightPanel().add(
							searchFrame.createSharkPanel(sortedSharksDistance.get(distance), ping.getLatestDate(sortedSharksDistance.get(distance).getName())));
							searchFrame.setVisible(true);
							FavouritesFrame.this.dispose();
						}
						else {
							searchFrame.getFinalResults().clear();
							searchFrame.getRightPanel().removeAll();
							searchFrame.setfinalResultsPanel();
							searchFrame.getRightPanel().add(
							searchFrame.createSharkPanel(sortedSharksDistance.get(distance), ping.getLatestDate(sortedSharksDistance.get(distance).getName())));
							searchFrame.setVisible(true);
							FavouritesFrame.this.dispose();
						}
						
					}
				});
				
				jpCenter.add(jlFavouriteShark);
				
			}
		}
	}

	/**
	 * Calculates the distance of the followed sharks between its last location and King's
	 * @param name
	 * @return
	 */
	private double calculateDistance(String name){
		Location location = jaws.getLastLocation(name);
	    double lat1 = location.getLatitude();
	    double lon1 = location.getLongitude();
	    
	    final double kingsLatitude = 51.5119;
	    final double kingsLongitute = 0.1161;
	    final double earthRadius = 6372.8; // In Kilometers.
        
	    double differenceLat = Math.toRadians(kingsLatitude - lat1);
        double differenceLong = Math.toRadians(kingsLongitute - lon1);
        
        lat1 = Math.toRadians(lat1);
        
        final double kingsLatitudeAngle = Math.toRadians(kingsLatitude);
        
        double part1 =  Math.pow(Math.sin(differenceLat / 2), 2) + 
        				Math.pow(Math.sin(differenceLong / 2), 2) * 
        				Math.cos(lat1) * Math.cos(kingsLatitudeAngle);
        double part2 = 2 * Math.asin(Math.sqrt(part1));
     
        double finalValue =  earthRadius * part2; //Distance To Kings.
        finalValue = Math.round(finalValue*100);
        finalValue = finalValue/100;
        
		return finalValue;
	}
	
	public String sharkNado(String name){
		Location location = jaws.getLastLocation(name);
	    double lat1 = location.getLatitude();
	    double lon1 = location.getLongitude();
	    
	    onLand = "";
	    
		URL urlForMap;
		try{
			urlForMap = new URL ("https://maps.googleapis.com/maps/api/elevation/json?locations="+ lat1 + "," + lon1 +"&key=AIzaSyA1JacXTmDieamsKSNKgOwW65PavPEwU-Y");
			String lineReader  = " ";	
			BufferedReader bffr = new BufferedReader(new InputStreamReader(urlForMap.openStream(), Charset.forName("UTF-8")));
					
			while((lineReader=bffr.readLine()) !=null){
				if(lineReader.contains("elevation")){
					Double elevation = Double.parseDouble(lineReader.split(":")[1].trim().replace(",", ""));
					if(elevation > 0){    
						onLand= ">>Sharknado!<<";
					}
				}
		
			}
			bffr.close();
		}
		catch (MalformedURLException e){
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		
        return onLand;
	}
	
	/**
	 * Reads the file specified for list of shark names line by line
	 * and adds it to the attribute followedSharks
	 * @param filePath
	 */
	public void readStoredFollowedSharks(String filePath){
		try {
		File file = new File(filePath);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		String line = null;
			while( (line = bufferedReader.readLine())!= null){
				followedSharks.add(line);
			}
			bufferedReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		
		}
	}
	
	public void sortFollowedSharks(){
		String currentSharkDate = null;
		for (String sharkDate: followedSharks){
			currentSharkDate = sharkDate;
			sortedSharksDistance.put(calculateDistance(currentSharkDate), jaws.getShark(currentSharkDate));
		}
	}
	
	/**
	 * Adds a controller for the button that opens up the map of followed sharks
	 * @param mapController
	 */
	public void addMapController(ActionListener mapController){
		jbFavMap.addActionListener(mapController);
		jbGoBack.addActionListener(mapController);
	}

	/**
	 * Setter method to set the list of followedSharks to the attribute 'followedSharks'
	 * @param followedSharks
	 */
	public void setFollowedSharks(HashSet<String> followedSharks){
		this.followedSharks = followedSharks;
	}
	
	/**
	 * Getter method to retrive the list of followed sharks
	 * @return list of followedSharks
	 */
	public HashSet<String> getFollowedSharks(){
		return  (HashSet<String>) followedSharks;
	}
	
}
