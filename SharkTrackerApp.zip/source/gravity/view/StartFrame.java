package gravity.view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

/**
 * A class to display the starting window for the user to use the application.
 * 
 * @author Ahnaf
 * @author Andhika
 * @author Nasim
 * @author Usman
 */
public class StartFrame extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private JPanel jpFrame;
	private JButton jbSearch;
	private JButton jbFavourites;
	private JMenuBar menuBar;
	private JMenu menu;
	private JMenuItem signup;
	private JMenuItem login;
	
	/**
	 * Constructor for the SearchFrame
	 */
	public StartFrame() {
		
		super("Amnity Police");
		setLayout(new BorderLayout());
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addWidget();
		createMenuBar();
		ImageIcon icon = new ImageIcon("images/sharkIcon.png");
		setIconImage(icon.getImage());
		pack();
	
	}
	
	/**
	 * Adds most of the components to the StartFrame
	 */
	private void addWidget() {
		
		jpFrame = new JPanel(new BorderLayout());
		jbSearch = new JButton("Search");
		jbFavourites = new JButton("Favourites");
		JPanel jpSouth = new JPanel(new GridLayout(2, 1));	
		jpFrame.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		jpFrame.add(jpSouth, BorderLayout.SOUTH);	
		jpFrame.add(new JLabel(new ImageIcon("images/SharkTrackerLogo.png")), BorderLayout.CENTER);
		jpSouth.add(jbSearch);
		jpSouth.add(jbFavourites);
		add(jpFrame);
	}
	
	/**
	 * Creates the menu bar for the user to login
	 */
	private void createMenuBar(){
		
		menuBar = new JMenuBar();
        menu = new JMenu("User Profile");
        signup = new JMenuItem("Sign-Up");
        login = new JMenuItem("Login");
        menu.add(signup);
        menu.add(login);
        menuBar.add(menu);
        this.setJMenuBar(menuBar);
	} 
	
	/**
	 * Sets a controller to the components of the StartFrame
	 * @param controller
	 */
	public void addController(ActionListener controller){
		
		jbSearch.addActionListener(controller);
		jbFavourites.addActionListener(controller);
		signup.addActionListener(controller);
		login.addActionListener(controller);
		
	}
	
	/**
	 * Getter method to retrive the favourites button
	 * @return jbFavourites
	 */
	public JButton getFavouritesButton(){
		return jbFavourites;
	}
	
}
