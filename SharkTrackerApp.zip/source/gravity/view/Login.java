package gravity.view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
/**
 * A class to for the Login that will pop up a JDialog box
 * 
 * @author Andhika
 * @author Nasim
 * @author Ahnaf
 * @author Usman
 *
 */
public class Login extends JDialog {

	private JTextField jtf;
	private JPasswordField jpf;
	private JButton loginButton;
	
	/**
	 * Constructs a dialog window prompting the user to login.
	 */
	public Login(){
		setTitle("Login");
		setSize(300,250);
		setLayout(new GridLayout(3,2));
		addWidgets();
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setResizable(false);		
	}
	
	/**
	 * Creates the components required for the dialog window.
	 */
	public void addWidgets() {

		JLabel name = new JLabel("Enter Name: ");
		name.setFont(new Font("Courier New", Font.ITALIC, 14));
		this.add(name);
		
		jtf = new JTextField();
		jtf.setPreferredSize(new Dimension(30,30));
		this.add(jtf);
		
		JLabel password = new JLabel("Enter Password: ");
		password.setFont(new Font("Courier New", Font.ITALIC, 14));
		this.add(password);
		
		jpf = new JPasswordField();
		jpf.setPreferredSize(new Dimension(30,30));
		this.add(jpf);

		loginButton = new JButton("Login");
		this.add(loginButton);
	}
	
	/**
	 * @return the JTextField.
	 */
	public JTextField getTextField() {
		return jtf;
	}
	
	/**
	 * @return the username typed.
	 */
	public String getInput() {
		return jtf.getText();
	}
	
	/**
	 * @return the JPasswordField.
	 */
	public JPasswordField getPasswordField() {
		return jpf;
	}
	
	/**
	 * @return the password typed.
	 */
	@SuppressWarnings("deprecation")
	public String getPassword() {
		return jpf.getText();
	}
	
	/**
	 * @param controller
	 */
	public void addController(ActionListener controller) {
		loginButton.addActionListener(controller);
	}
}