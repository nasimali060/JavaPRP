package gravity.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeMap;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;

import api.jaws.Jaws;
import api.jaws.Shark;
import gravity.model.*;

/**
 * A class to allow user to search for sharks in an interactive GUI
 * @author Andhika
 * @author Nasim
 * @author Ahnaf
 * @author Usman
 *
 */
public class SearchFrame extends JFrame{

	private static final long serialVersionUID = 2475261946584528309L;
	private Jaws jaws;
	private JPanel jpFrame;
	private JPanel jpRightPanel;
	private JButton jbSearchButton;
	private JButton jbStatistics;
	private JButton jbGoBack;
	private TreeMap<String, Shark> finalSearchResults;
	private HashSet<String> followedSharks;
	private JComboBox<String> jcbGender;
	private JComboBox<String> jcbTrackingRange;
	private JComboBox<String> jcbStageOfLife;
	private JComboBox<String> jcbTagLocation;
	private JPanel jpFinalResultsPanel;
	private RandomSharkGenerator sharkGenerator;
	private String sharkOfTheDay;
	

	/**
	 * Constructor for a SearchFrame class
	 * @param jaws
	 * @throws IOException
	 */
	public SearchFrame(Jaws jaws) throws IOException {
		
		super("Search");
		this.jaws = jaws;
		jpFrame = new JPanel(new BorderLayout());
		jbSearchButton  = new JButton("Search");
		followedSharks = new HashSet<String>();
		sharkGenerator = new RandomSharkGenerator(jaws);
		jpFrame.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		setSize(900, 750);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		add(jpFrame, BorderLayout.CENTER);
		createLeftPanel();
		createCopyright();
		readStoredFollowedSharks("data/FavouriteSharks.txt");
		createSharkOfTheDay();
		ImageIcon icon = new ImageIcon("images/sharkIcon.png");
		setIconImage(icon.getImage());
		pack();
		
	}
	
	/**
	 * Creates the shark of the day once every 24 hours
	 */
	private void createSharkOfTheDay(){
		
		//A file to store the name of the shark of the day
		File file = new File("data/SharkOfTheDay.txt");
		
		//A variable to store the input from the SharkOfTheDay text file
		String line = null;
		
		//Takes in the date and time at present
		Date today  = new Date();
		
		try {
			
			//An input reader to read the SharkOfTheDay text file
			Scanner scanner = new Scanner(file);
			
			//Takes in the first line of the text file and stores in in 'line' variable
			line  = scanner.nextLine();
			
			//Closes the reader
			scanner.close();
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//A String variable to store the date part of the input from the reader
		String stringSharkOfTheDayDate = line.substring(line.lastIndexOf("_")+1, line.length());
		
		//A variable to create the format of a date
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		
		//A variable of type Date to store the date part of the input
		Date dateSharkOfTheDayDate = null;
		try {
			
			//Creates a Date from the String representing a date
			dateSharkOfTheDayDate = dateFormat.parse(stringSharkOfTheDayDate);
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		//A Calendar to manipulate dates
		Calendar sharkOfTheDayCalendar = Calendar.getInstance();
		
		//Set the date/time of the calendar to the date of 'dateSharkOfTheDayDate'
		sharkOfTheDayCalendar.setTime(dateSharkOfTheDayDate);
		
		//Add one day to the 'dateSharkOfTheDayDate'
		sharkOfTheDayCalendar.add(Calendar.DATE, 1);
	
		//Checks if the date of the 'dateSharkOfTheDayDate'(added by 1 day) is before the current date
		if(sharkOfTheDayCalendar.getTime().before(today)){
			
			//If it is, then generate a new random shark
			sharkGenerator.generateRandomShark();
			
			//Reads the file again, as a new random shark has been generated
			Scanner scanner = null;
			try {
				scanner = new Scanner(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				}
			
			//Store the first line read by the scanner into 'line' variable
			line  = scanner.nextLine();
			
			//Close the scanner after reading it
			scanner.close();
		}
		
		//Set the field 'sharkOfTheDay' to be the name part of the 'line'
		sharkOfTheDay = line.substring(0, line.lastIndexOf("_"));
		
		//Call the method createSharkOfTheDayPanel()
		createTopPanel(sharkOfTheDay);
		
	}
	
	/**
	 * Creates the top panel of the SearchFrame class
	 * @param sharkName
	 */
	private void createTopPanel(String sharkName){
		
		//A overall container for the top panel
		JPanel jpTopPanel = new JPanel(new BorderLayout());
		
		//A Panel for the shark of the day
		JPanel jpSharkOfTheDay = new JPanel(new FlowLayout());
		
		//A Lebel to display the shark of the day
		JLabel jlSharkOfTheDay = new JLabel("Shark of the day: " + sharkName);
		
		//A button to click on the link of the video of the shark (if one exists)
		JButton jbSharkOfTheDay = new JButton();
		
		//Set the text of the button to 'Click for video'
		jbSharkOfTheDay.setText("<HTML>Click for video</HTML>");
		
		//Get the link of the video of the shark
		final URI sharkVideo = verifyURI(sharkName, jbSharkOfTheDay);
		
		//Add an actionlistener for the sharkOfTheDay button
		//Clicking the button will open the browser to go to the link specified
		jbSharkOfTheDay.addActionListener(new ActionListener(){
		
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (Desktop.isDesktopSupported()) {
				      try {
				        Desktop.getDesktop().browse(sharkVideo);
				      } catch (IOException e) { 
				    	 System.out.println("Error with the web browser");
				      }
				} 
			}
			
		});
		
		//Instiantiate the go back button and set the text to "Go Back"
		jbGoBack = new JButton("Go Back");
		
		
		jpTopPanel.add(jbGoBack, BorderLayout.WEST);
		jpTopPanel.add(jpSharkOfTheDay, BorderLayout.CENTER);
		
		jlSharkOfTheDay.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		
		jpSharkOfTheDay.add(jlSharkOfTheDay);
		jpSharkOfTheDay.add(jbSharkOfTheDay);
		
		
		jpFrame.add(jpTopPanel, BorderLayout.NORTH);
		
	}
	
	/**
	 * Verify if the link for the video of the shark exists.
	 * Unavailable link will disable the button for the link
	 * @param sharkName
	 * @param jbSharkOfTheDay
	 * @return URI
	 */
	private final URI verifyURI(String sharkName, JButton jbSharkOfTheDay){
		jbSharkOfTheDay.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		String link = jaws.getVideo(sharkName);
		URI sharkVideo = null;
		
		if(link.equals("No footage available for this shark :-(")){
			jbSharkOfTheDay.setEnabled(false);
		}
		try {
			sharkVideo = new URI(link);
		} catch (URISyntaxException e) {
			jbSharkOfTheDay.setText("No video available");
			//e.printStackTrace();
		}
		return sharkVideo;
	}
	
	/**
	 * Creates the left panel of the SearchFrame
	 */
	private void createLeftPanel() {

		JPanel jpLeftPanelGap = new JPanel();
		JPanel jpMainLeftPanel = new JPanel(new BorderLayout());
		JPanel titlePanel = new JPanel(new GridLayout(2, 1));
		JPanel jpButtons = new JPanel();
		JLabel jlTitle = new JLabel("Shark Tracker");
		JPanel jpFilter = new JPanel(new GridLayout(13, 1));
		String[] trackingRanges = { "Past 24 Hours", "Past Week", "Past Month" };
		String[] sharkGenders = { "All", "Male", "Female" };
		String[] sharkStageOfLife = { "All", "Mature", "Immature", "Undetermined" };
		ArrayList<String> sharkTagLocationsList = jaws.getTagLocations();
		String[] sharkTagLocations = new String[sharkTagLocationsList.size()];
		sharkTagLocations = sharkTagLocationsList.toArray(sharkTagLocations);

		jcbGender = new JComboBox<String>(sharkGenders);
		jcbTrackingRange = new JComboBox<String>(trackingRanges);
		jcbStageOfLife = new JComboBox<String>(sharkStageOfLife);
		jcbTagLocation = new JComboBox<String>(sharkTagLocations);
		jcbTagLocation.addItem("All");
		jcbTagLocation.setSelectedItem("All");
		jbSearchButton = new JButton("Search");
		jbStatistics = new JButton("Statistics");
		jpRightPanel = new JPanel(new BorderLayout());
	
		jpButtons.setLayout(new BoxLayout(jpButtons, BoxLayout.LINE_AXIS));
		jlTitle.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
		jpMainLeftPanel.add(titlePanel, BorderLayout.NORTH);
		titlePanel.add(jlTitle);
		jpMainLeftPanel.add(jpFilter, BorderLayout.CENTER);
		
		jpFilter.add(new JLabel("Tracking Range"));
		jpFilter.add(jcbTrackingRange);
		
		jpFilter.add(new JSeparator(JSeparator.HORIZONTAL));
		jpFilter.add(new JLabel("Gender"));
		jpFilter.add(jcbGender);
		
		jpFilter.add(new JSeparator(JSeparator.HORIZONTAL));
		jpFilter.add(new JLabel("Stage Of Life"));
		jpFilter.add(jcbStageOfLife);
		
		jpFilter.add(new JSeparator(JSeparator.HORIZONTAL));
		jpFilter.add(new JLabel("Tag Location"));
		jpFilter.add(jcbTagLocation);
		
		jpFilter.add(new JSeparator(JSeparator.HORIZONTAL));
		jpFilter.add(jpButtons);
		
		jpButtons.add(jbSearchButton);
		jpButtons.add(jbStatistics);

		jpMainLeftPanel.add(new JLabel(new ImageIcon("images/SharkTrackerLogo.png")), BorderLayout.SOUTH);
		jpMainLeftPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		jpLeftPanelGap.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		jpLeftPanelGap.add(jpMainLeftPanel);
		
		jpRightPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.BLACK));
		jpFrame.add(jpLeftPanelGap, BorderLayout.WEST);
		jpFrame.add(jpRightPanel, BorderLayout.CENTER);

	}
	
	/**
	 * Creates the copyright statement at the bottom of the SearchFrame
	 */
	private void createCopyright() {
		JLabel jlCopyRight = new JLabel(jaws.getAcknowledgement());
		add(jlCopyRight, BorderLayout.SOUTH);
	}
	
	/**
	 * Creates the right panel of the SearchFrame, to display the search results
	 * If the result result is empty, the right panel will display "NO RESULTS FOUND!"
	 * Otherwise, details of sharks that matched the criteria specified by the user
	 * will be shown on the right panel
	 * @see createSharkPanel
	 */
	public void createRightPanel() {
		
		JPanel jpFinalResultsPanel = new JPanel();
		jpFinalResultsPanel.removeAll();
		jpFinalResultsPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		
		
		if (finalSearchResults.isEmpty()){
			
			jpFinalResultsPanel.setLayout(new BorderLayout());
			JLabel jlnoResults = new JLabel("NO RESULTS FOUND!");
			jlnoResults.setFont(new Font("Trebuchet MS", Font.BOLD, 40));
			jlnoResults.setForeground(Color.BLACK);
			jpFinalResultsPanel.add(jlnoResults, BorderLayout.WEST);
		
		}
		else{
			
			jpFinalResultsPanel.setLayout(new GridLayout(0, 1));
			for (String sharkDate: finalSearchResults.keySet()) {
				
				String currentSharkDate = sharkDate;
				Shark currentShark = finalSearchResults.get(sharkDate);
				jpFinalResultsPanel.add(createSharkPanel(currentShark, currentSharkDate));
				
			}
		
		jpFinalResultsPanel.revalidate();
		jpFinalResultsPanel.repaint();
		jpRightPanel.add(new JScrollPane(jpFinalResultsPanel, 
		JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
		JScrollPane.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);
		
		}
	}
	
	/**
	 * Creates the panel for each individual shark
	 * @param shark
	 * @param sharkDate
	 * @return jpMainRightPanel
	 */
	protected JPanel createSharkPanel(Shark shark, String sharkDate){
		
		JPanel jpMainRightPanel = new JPanel(new BorderLayout());
		JPanel jpSharkDetails = new JPanel(new GridLayout(6, 2));
		JPanel jpSharkDescription = new JPanel(new GridLayout(2,1));

		jpSharkDetails.add(new JLabel("Name: "));
		jpSharkDetails.add(new JLabel(shark.getName()));
		jpSharkDetails.add(new JLabel("Gender: "));
		jpSharkDetails.add(new JLabel(shark.getGender()));
		jpSharkDetails.add(new JLabel("Stage of Life: "));
		jpSharkDetails.add(new JLabel(shark.getStageOfLife()));
		jpSharkDetails.add(new JLabel("Species: "));
		jpSharkDetails.add(new JLabel(shark.getSpecies()));
		jpSharkDetails.add(new JLabel("Length: "));
		jpSharkDetails.add(new JLabel(shark.getLength()));
		jpSharkDetails.add(new JLabel("Weight: "));
		jpSharkDetails.add(new JLabel(shark.getWeight()));

		String description = shark.getDescription();
		StringBuilder descriptionBuilder = new StringBuilder(description.length());
		descriptionBuilder.append("<html>" + description + "<html>");
		
		JLabel jlDescriptionContents = new JLabel(descriptionBuilder.toString());
		
		jpSharkDescription.add(new JLabel("Description: "));
		jpSharkDescription.add(jlDescriptionContents);
		jpMainRightPanel.add(jpSharkDetails,BorderLayout.NORTH);
		jpMainRightPanel.add(jpSharkDescription,BorderLayout.CENTER);
		
		JPanel jpPingAndFav = new JPanel(new BorderLayout());
		JButton jbFavouritesButton = new JButton("Follow");
		
		jpPingAndFav.add(new JLabel("Last Ping : " + sharkDate), BorderLayout.WEST);
		jpPingAndFav.add(jbFavouritesButton, BorderLayout.EAST);
		jpMainRightPanel.add(jpPingAndFav, BorderLayout.SOUTH);
		
		jpMainRightPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.gray));
		jpMainRightPanel.setPreferredSize(new Dimension(470, 500));
		
		if (followedSharks.contains(shark.getName())){
			jbFavouritesButton.setText("Following");
		}
		
		jbFavouritesButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent event) {
				if(event.getActionCommand().equals("Follow")){
					
					jbFavouritesButton.setText("Following");
					followedSharks.add(shark.getName());
					addLineToFile("data/FavouriteSharks.txt", shark.getName());	
				
				}
				else if(event.getActionCommand().equals("Following")){
					
					jbFavouritesButton.setText("Follow");
					followedSharks.remove(shark.getName());
					removeLineFromFile("data/FavouriteSharks.txt", shark.getName());
					
				}
			}
		});
		
		return jpMainRightPanel;
		
	}
	
	/**
	 * Adds a controller to the SearchFrame
	 * @param controller
	 */
	public void addController(ActionListener controller){
		jbSearchButton.addActionListener(controller);
		jbStatistics.addActionListener(controller);
		jbGoBack.addActionListener(controller);
	}
	
	/**
	 * Setter method to set the result of the search from the Search class
	 */
	public void setfinalResultsPanel(){
		jpFinalResultsPanel = new JPanel();
		jpRightPanel.add(jpFinalResultsPanel, BorderLayout.CENTER);
	}
	
	/**
	 * Getter method for the result of the sharks that have been searched
	 * @return finalSearchResults
	 */
	public TreeMap<String, Shark> getFinalResults(){
		return finalSearchResults;
	}
	
	/**
	 * Getter method to get the results of the searches
	 * @return jpFinalResultsPanel
	 */
	public JPanel getFinalResultsPanel(){
		return jpFinalResultsPanel;
	}
	
	/**
	 * Getter method to retrieve the right panel of the SearchFrame
	 * @return jpRightPanel
	 */
	public JPanel getRightPanel(){
		return jpRightPanel;
	}
	
	/**
	 * Getter method to retrieve the selected item of the tracking range
	 * @return jcbTrackingRange selected item
	 */
	public String getTrackingRangeInput(){
		return jcbTrackingRange.getSelectedItem().toString();
	}
	
	/**
	 * Getter method to retrieve the selected item of the gender
	 * @return jcbGender selected item
	 */
	public String getGenderInput(){
		return jcbGender.getSelectedItem().toString();
	}
	
	/**
	 * Getter method to retrieve the selected item of the stage of life
	 * @return jcbGenderStageOfLife selected item
	 */
	public String getStageOfLifeInput(){
		return jcbStageOfLife.getSelectedItem().toString();
	}
	
	/**
	 * Getter method to retrieve the selected item of the tag location
	 * @return jcbTagLocation selected item
	 */
	public String getTagLocationInput(){
		return jcbTagLocation.getSelectedItem().toString();
	}
	
	/**
	 * Setter method to set the results of the search done by the Search class
	 * to this class finalSearchResults attribute
	 * @param searchResults
	 * @see Search class
	 */
	public void setSearchResults(TreeMap<String, Shark> searchResults){
		finalSearchResults = searchResults;
	}
	
	/**
	 * Setter method to set the followed sharks to the followedSharks attribute
	 * @param followedSharks
	 */
	public void setFollowedSharks(HashSet<String> followedSharks){
		this.followedSharks = (HashSet<String>) followedSharks;
	}
	
	/**
	 * Getter method to retrieve the followedSharks
	 * @return followedSharks
	 */
	public HashSet<String> getFollowedSharks(){
		return (HashSet<String>) followedSharks;
	}
	
	/**
	 * Removes a String from the specified file
	 * It will go through all of the text line by line, 
	 * and put the ones that do not match the specified String in a temporary file.
	 * Finally, it will rename the temporary file to the previous file, leaving the specified String.
	 * @param file
	 * @param lineToRemove
	 */
	public void removeLineFromFile(String file, String lineToRemove) {
		 
		try {
			 
		      File inFile = new File(file);
		       
		      //Construct the new file that will later be renamed to the original filename. 
		      File tempFile = new File("data/Temp.tmp");
		      
		      BufferedReader br = new BufferedReader(new FileReader(file));
		      PrintWriter pw = new PrintWriter(new FileWriter(tempFile));
		      
		      String line = null;
		 
		      //Read from the original file and write to the new 
		      //unless content matches data to be removed.
		      while ((line = br.readLine()) != null) {
		        if (!line.equals(lineToRemove)) {
		          pw.println(line);
		          pw.flush();
		        }
		      }
		      pw.close();
		      br.close();
		      
		      //Delete the original file
		      inFile.delete();
		      
		      //Rename the new file to the filename the original file had.
		      tempFile.renameTo(inFile);
		      
		    }
		    catch (FileNotFoundException ex) {
		      ex.printStackTrace();
		    }
		    catch (IOException ex) {
		      ex.printStackTrace();
		    }
		
		
	}
	
	/**
	 * Adds the specified String line by line to the specified file
	 * @param file
	 * @param lineToAdd
	 */
	private void addLineToFile(String file, String lineToAdd){
		
		File outFile = new File(file);
		try {
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(outFile, true));
			bufferedWriter.write(lineToAdd);
			bufferedWriter.newLine();
			bufferedWriter.close();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Reads all the followedSharks in the specified file
	 * @param filePath
	 */
	public void readStoredFollowedSharks(String filePath){
		
		try {
		File file = new File(filePath);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		
		String line = null;
			
			while( (line = bufferedReader.readLine())!= null){
				followedSharks.add(line);
			}
		bufferedReader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		
	}

}
