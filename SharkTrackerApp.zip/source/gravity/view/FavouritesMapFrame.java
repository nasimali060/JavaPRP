package gravity.view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
/**
 * 
 * @author Ahnaf
 * @author Andhika
 * @author Nasim
 * @author Usman
 * 
 * This class has all the methods which are needed to create the map which shows all the favourite sharks all over the world.
 * 
 *
 */
public class FavouritesMapFrame extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private String mapURL;	
	private JButton jbGoBack;
	/**
	  * 
	  * @throws MalformedURLException
	  * 
	  * 
	  */
 
	public FavouritesMapFrame() throws MalformedURLException{
		super("Your Favorite Sharks!");
		setLayout(new BorderLayout());
		setSize(800,800);
		generatePredefinedURL ();
		ImageIcon icon = new ImageIcon("images/sharkIcon.png");
		setIconImage(icon.getImage());
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	
	}
	/**
	 * This method is generating the predefined URL.
	 */
	public void generatePredefinedURL () {
		
		mapURL = "http://maps.googleapis.com/maps/api/staticmap?" + "maptype=satellite&scale=2&zoom=1&size=640x400" + "&sensor=true";
	}
	/**
	 * This method creates the markers on the map according to the location(latitude, longitude) of the shark
	 * @param latitude
	 * @param longitude
	 */
	public void createMarkersOnMap (double latitude, double longitute) {
		
		mapURL += "&markers="+latitude;
		mapURL += ","+longitute;
	}
	/**
	 * This method a new URL with the previous URL
	 * @return newURL
	 * @throws MalformedURLException
	 */
	public URL generateNewURL () throws MalformedURLException {								 
	
		URL newURL = new URL(mapURL);														
		return newURL;																	   	 
	}
	/**
	 * This method creates the Frame and the panels which contain the map of the followed sharks.
	 * Also it creates a go back button.
	 * @throws MalformedURLException
	 */

	public void displayMap() throws MalformedURLException {
		
		ImageIcon mapPicIcon = new ImageIcon( new ImageIcon(generateNewURL())				
		.getImage().getScaledInstance( 1066, 666, java.awt.Image.SCALE_SMOOTH));
		
		JLabel jlmapHolder = new JLabel();													
		jlmapHolder.setIcon(mapPicIcon);
		JPanel jpmapHolder = new JPanel();
			
		jpmapHolder.add(jlmapHolder);
		this.add(jpmapHolder,BorderLayout.CENTER);
																		       
		//this.setLocationRelativeTo(null);	
		
		JPanel jpNorth = new JPanel(new BorderLayout());
		jbGoBack = new JButton("Go Back");
		jpNorth.add(jbGoBack,BorderLayout.WEST);
		this.add(jpNorth,BorderLayout.NORTH);
		this.pack();
		this.setLocationRelativeTo(null);
		
	}
	
	/**
	 * adding an actionlistener to the "Go Back" button.
	 * @param mapController
	 */
	public void addMapController(ActionListener mapController){
		jbGoBack.addActionListener(mapController);
	}
	
 
}