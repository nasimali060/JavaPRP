package gravity;

import java.io.IOException;

import api.jaws.Jaws;
import gravity.controller.*;
import gravity.model.*;
import gravity.view.*;
/**
 * The main method of the Shark Tracker program
 * 
 * @author Andhika
 * @author Nasim
 * @author Ahnaf
 * @author Usman
 *
 */
public class Main {

	public static void main(String[] args) throws IOException {
	
		Jaws jaws = new Jaws("4858yafFqkmaKcGp","XR90JLdpYJc3Ywgh");
		
		//Instantiate Model
		LatestPingGenerator ping = new LatestPingGenerator(jaws);
		
		//Instantiate Model
		Search search = new Search(jaws, ping);
		
		//Instantiate View searchFrame
		SearchFrame searchFrame = new SearchFrame(jaws);
		
		//Instantiate View favourites
		FavouritesFrame favourites = new FavouritesFrame(jaws, searchFrame, ping);
		
		//Instantiate View startFrame
		StartFrame startFrame = new StartFrame();
		
		//Instantiate View userDialog
		UserProfile userDialog = new UserProfile();
		
		//Instantiate View loginDialog
		Login loginDialog = new Login();
		
		//Instantiate  View favouritesMapFrame
		FavouritesMapFrame favouritesMapFrame = new FavouritesMapFrame();
		
		//Instantiate Model
		StatisticsData chartDatas = new StatisticsData(jaws,ping);	
		
		//Instantiate Controller
	    Controller controller = new Controller(jaws, chartDatas, startFrame, searchFrame, favourites, userDialog, loginDialog, search, favouritesMapFrame);
		
	    //Start method to the program
		controller.startProgram(true);
		
		
	}


}
