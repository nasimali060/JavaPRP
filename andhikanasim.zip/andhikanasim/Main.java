package andhikanasim;


import andhikanasim.looselycoupled.*;
/**
 * The main method where the program executes 
 * @author AndhikaNasim
 * 
 */
public class Main {
	
	
	//Main method
	public static void main(String[] args) {
		
		//Two instances of Evidence created
		Evidence dna = new Evidence ("DNA");
	
		Evidence footprint = new Evidence ("FootPrint");
		
		//Printed the evidence using the to-string method in the evidence class
		System.out.println(dna);
		
		System.out.println(footprint);
		
		//created a new evidence box
		EvidenceBox evidenceBox = new EvidenceBox(2005000381, "S.Avery");
		
		//added each of the evidences
		evidenceBox.addEvidence(dna);
		
		evidenceBox.addEvidence(footprint);
		
		evidenceBox.displayEvidence();
		
		//Two new policeman instances created
		Policeman jlenk = new Policeman ("J.Lenk");
		
		Policeman acolborn = new Policeman("A.Colborn");
		
		//Policeman collects an EvidenceBox 
		jlenk.addEvidenceBox(evidenceBox);
		
		/*
		 * Policeman searches for a specific evidence box using a case number and a specific 
		 * evidence type 
		 */
		jlenk.getDesiredbox(2005000381, "DNA");
		
		//Instance of the optional console GUI was created, for user interactivity with the other classes
		Gui gui = new Gui(dna,footprint);
		
		}
	
	}


