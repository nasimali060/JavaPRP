package andhikanasim.looselycoupled;

import java.util.ArrayList;
/**
 * The Policeman class represents a Police man
 * @author AndhikaNasim
 * @version looselycoupled
 *
 */

public class Policeman {
	
	private String name;
	
	private ArrayList<EvidenceBox> evidenceBoxes;
	/**
	 * A constructor that creates a policeman object with a field name and an ArrayList to store EvidenceBoxes
	 * the policeman collects
	 * @param name takes a String which is a name
	 */
	public Policeman(String name){
		
		this.name = name;
		
		evidenceBoxes = new ArrayList<>();
	}
	
	/**
	 * Adds an EvidenceBox object into the ArrayList
	 * @param evidenceBox takes an EvidenceBox object
	 */
	public void addEvidenceBox(EvidenceBox evidenceBox){
		evidenceBoxes.add(evidenceBox);
	}
	/**
	 * A method to search for a specific type of evidence from a specific evidence box the policeman 
	 * collected
	 * @param caseNumber takes an int
	 * @param desiredEvidence takes an String
	 */
	public void getDesiredbox(int caseNumber, String desiredEvidence){
		/*
		 * Created two ArrayLists that one for when it goes through each EvidenceBox and stores it in the 
		 * list, and another that will store the final result the method is for
		 */
		ArrayList<Evidence> desiredEvidences = new ArrayList<Evidence>();
		
		ArrayList<EvidenceBox> tempEvidenceBox = new ArrayList<EvidenceBox>();
		
		// A loop that goes through each evidence box the police man has in his/her evidenceboxes collected
		
		for (int i = 0; i < evidenceBoxes.size();i++){
			
			EvidenceBox evidenceBox = evidenceBoxes.get(i);
			
			tempEvidenceBox.add(evidenceBox);
			
		//An if statement that will checks the casenumber he wants with the EvidenceBoxes he/she has
			
			if(caseNumber == evidenceBox.getCaseNumber()){
		/*
		 * If found then will use a method in EvidenceBox class which checks for the desired evidence, 
		 * and will add that to the ArrayList of desiredEvidences	
		 */		
				desiredEvidences = evidenceBox.getEvidenceByType(desiredEvidence);
				
			}
			
		}
		
		System.out.println("Pieces of " + desiredEvidence +" evidence in Evidence Box number " + 
		+caseNumber + " found by " + name + " : " + desiredEvidences );
	 
	}
	
	/**
	 * A to-string method to print the name of the policeman object when it is called for printing
	 */
	public String toString(){
		
		return name;
	}
}
