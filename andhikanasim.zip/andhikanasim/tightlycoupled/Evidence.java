package andhikanasim.tightlycoupled;

/**
 * The Evidence class represents an evidence
 * @author AndhikaNasim
 * @version tighlycoupled
 */
public class Evidence {
	
	/**
	 * evidenceCollected field stores the String representation of an evidence
	 */
	private String evidenceCollected;
	
	/**
	 * 
	 * @param evidence takes a String to represent an evidence
	 */
	public Evidence(String evidence){
		
		evidenceCollected = evidence;
		
	}
	
	/**
	 * Method for retrieving an evidence
	 * @return evidenceCollected in a String
	 */
	public String getEvidence(){
		
		return evidenceCollected;
	}
	
	/**
	 * Returns a String representation of an Evidence when printed
	 */
	public String toString(){
		
		return evidenceCollected;
	}
	
	
}
