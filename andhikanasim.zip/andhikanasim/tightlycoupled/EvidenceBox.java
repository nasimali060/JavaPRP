package andhikanasim.tightlycoupled;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * The EvidenceBox class represents an evidence box which is a collection of evidences
 * @author AndhikaNasim
 * @version tightlycoupled
 */
public class EvidenceBox {
	
	/**
	 * The evidences field stores a list of Evidence in an EvidenceBox
	 */
	private ArrayList <Evidence> evidences;
	
	/**
	 * The caseNumber field stores the case number of each EvidenceBox
	 */
	private int caseNumber;
	
	/**
	 * The caseName field stores the case name of each EvidenceBox
	 */
	private String caseName;
	
	/**
	 * Constructor for an EvidenceBox
	 * @param caseNumber takes an int
	 * @param caseName takes a String
	 */
	public EvidenceBox(int caseNumber, String caseName){
		evidences = new ArrayList<>();
		this.caseNumber = caseNumber;
		this.caseName = caseName;
	}

	/**
	 * This method displays the evidences preceded by the number of its occurrences in the EvidenceBox
	 */
	public void displayEvidence(){
		ArrayList<String> allEvidences = new ArrayList<String>();
		
		/*
		 * Go through every evidences present in the EvidenceBox,
		 * and stores each of them in a list of Strings
		 */
		for(int i = 0; i < evidences.size(); ++i){
			allEvidences.add(evidences.get(i).getEvidence());
		}
		
		/*
		 * A set of Evidences to store one of each type
		 */
		Set<String> unique = new HashSet<String>(allEvidences);
		
		/*
		 * Iterates through the set of Evidences
		 * And prints out the number of occurrences of each type followed by the Evidence type
		 */
		for(String evidenceType: unique){
			
			System.out.println(Collections.frequency(allEvidences, evidenceType) + "x " + evidenceType);
			
		}
	}
	
	/**
	 * This method adds an evidence to EvidenceBox
	 */
	public void addEvidence(Evidence evidenceType){
		evidences.add(evidenceType);
	}
	
	/**
	 * 
	 * @return int the case number of the EvidenceBox
	 */
	public int getCaseNumber(){
		return caseNumber;
	}
	
	/**
	 * 
	 * @return the list of Evidence in the EvidenceBox
	 */
	public ArrayList<Evidence> allEvidences(){
		return evidences;
	}
	
}
