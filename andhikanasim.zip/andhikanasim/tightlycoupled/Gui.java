package andhikanasim.tightlycoupled;

import java.util.Scanner;
/**
 * A simple console based user interactivity
 * @author AndhikaNasim
 * @version tightlycoupled
 *
 */
public class Gui {
	public Gui(Evidence evi, Evidence dence){
		gui(evi,dence);
	}
	/**
	 * A static method which uses a switch statement to make a menu that allows users to open
	 * and interact with the code further or to just ignore the GUI and just close the program
	 * if open then will start an another static method that actually interacts with the other 
	 * classes
	 * @param evi takes an Evidence object
	 * @param dence takes an Evidence object
	 */
	public static void gui(Evidence evi, Evidence dence){
		Scanner scanner = new Scanner(System.in);
		System.out.println("\nPlease select what do you want to do with the optional Program"
				+ "\nType 1 to Open program \nType 2 to Close program");
		String programChoiceNumber = scanner.nextLine();
		switch (programChoiceNumber){
				case "1": System.out.println("Program Openned");
					choices(evi,dence,scanner);
					break;
				case "2": System.out.print("Closing program...");
				scanner.close();
				System.out.println("\nProgram Terminated!");
				break;
				default: System.out.println("Please type only a number from the choices provided!!!");
				gui(evi,dence);
				break;
				} 
		
	}
	/**
	 * A static method that was created using a switch statement that allows users to interact with 
	 * the code from the other classes but the code here is not important for the other classes
	 * and can be removed any time. 
	 * @param evi takes an Evidence object
	 * @param dence takes an Evidence object
	 * @param scan takes an Scanner object
	 */
	public static void choices(Evidence evi,Evidence dence,Scanner scan){
		System.out.println("\nWhat do you want to do? : \nType 1 for creating a new specific evidence"
				+ "\nType 2 for creating a new Evidence box \nType 3 for creating a new policeman "
				+ "\nType 4 for Back to Main Menu");
				String choiceNumber = scan.nextLine();
				Evidence a;
				EvidenceBox b;
				switch (choiceNumber){
					case "1" : System.out.println("Which type of evidence do you want to make?");
						String newEvidence = scan.nextLine();
						a = new Evidence (newEvidence);
						System.out.println(a);
						choices(evi, dence,scan);
						break;
					case "2": System.out.println("Please input the new case number?");
						String number = scan.nextLine();
						int caseNumber;
						while(true){
						try {
							caseNumber = Integer.parseInt(number);
							System.out.println("Please Input a new case name?");
							String caseName = scan.nextLine();
							b = new EvidenceBox(caseNumber,caseName);
							System.out.println("New Evidence box created with case number : " 
							+ caseNumber + " with case name : " + caseName);
							addExistingEvidences(evi,dence,b,scan);
							
							break;
						}
						catch (NumberFormatException caseNum){
							//do nothing LOL
						}
						System.out.println("Error please enter a number not a text or a mixture "
								+ "of text and numbers");
						number = scan.nextLine();
						}
						break;
					case "3" :  System.out.println("Please input a new Police Name?");
							String policeName = scan.nextLine();
							Policeman c = new Policeman(policeName);
							System.out.println(c);
							choices(evi, dence,scan);
							break;
					case "4" : System.out.println("Sub-Menu-Program Closed");
							gui(evi,dence);
							break;
					default : System.out.println("You have entered an invalid option, try again!!!");
							choices(evi, dence,scan);
							break;
				}
			
		
		}
	/**
	 * A static method created using a switch statement that allows users to add existing Evidence
	 * objects to their new evidence box
	 * @param evi takes an Evidence object
	 * @param dence takes an Evidence object
	 * @param eviBox takes an EvidenceBox object
	 * @param scanner takes an Scanner object
	 */
		public static void addExistingEvidences(Evidence evi, Evidence dence,EvidenceBox eviBox,
				Scanner scanner){
			System.out.println("\nWhich of the existing evidences do you want to add to the "
					+ "new Evidence box created?\nType 1 to add " + evi +"\nType 2 to add " + dence+""
							+ "\nType 3 to check your Evidence Box\nType 4 if you want to go back to menu");
			String choice = scanner.nextLine();
			switch(choice){
				case "1" : eviBox.addEvidence(evi);
				System.out.println(evi + " Has been added to the new Evidence Box created.");
				addExistingEvidences(evi,dence,eviBox,scanner);
				break;
				case "2" : eviBox.addEvidence(dence);
				System.out.println(dence + " Has been added to the new Evidence Box created.");
				addExistingEvidences(evi,dence,eviBox,scanner);
				break;
				case "3" : System.out.println("Inside your evidence box is the following evidence : "
				+eviBox.allEvidences());
				addExistingEvidences(evi,dence,eviBox,scanner);
				break;
				case "4" : //ignore
				choices(evi,dence,scanner);
				break;
				default : System.out.println("Try again");
				addExistingEvidences(evi,dence,eviBox,scanner);
				break;
			}
		}
}
