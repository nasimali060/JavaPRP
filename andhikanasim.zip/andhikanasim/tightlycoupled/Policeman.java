package andhikanasim.tightlycoupled;

import java.util.ArrayList;
/**
 * The Policeman class represents a Police man
 * @author AndhikaNasim
 * @version tightlycoupled
 *
 */

public class Policeman {
	private String name;
	private ArrayList<EvidenceBox> evidenceBoxes;
	/**
	 * A constructor that creates a policeman object with a field name and an ArrayList to store EvidenceBoxes
	 * the policeman collects
	 * @param name takes a String which is a name
	 */
	public Policeman(String name){
		this.name = name;
		evidenceBoxes = new ArrayList<>();
	}
	/**
	 * Adds an EvidenceBox object into the ArrayList
	 * @param evidenceBox takes a EvidenceBox object
	 */
	public void addEvidenceBox(EvidenceBox evidenceBox){
		evidenceBoxes.add(evidenceBox);
	}
	/**
	 * A method to search for a specific type of evidence from a specific evidence box the policeman 
	 * collected
	 * @param caseNumber takes an int
	 * @param desiredEvidence takes an String
	 */
	public void getDesiredbox(int caseNumber, String desiredEvidence){
		//Created three ArrayLists 
		ArrayList<Evidence> desiredEvidences = new ArrayList<Evidence>();
		ArrayList<EvidenceBox> tempEvidenceBox = new ArrayList<EvidenceBox>();
		ArrayList<Evidence> tempEvidence = new ArrayList<Evidence>();
		
		//A loop that goes through each of the evidenceBoxes arrayList which is a collection of EvidenceBoxes
		
		for (int i = 0; i < evidenceBoxes.size();i++){
			
			//Will add each evidence box to a temporary storage
			
			EvidenceBox evidenceBox = evidenceBoxes.get(i);
			tempEvidenceBox.add(evidenceBox);
			
			//Will check for each of the EvidenceBoxes that the caseNumber matches the one he/she desires	
			
			if(caseNumber == evidenceBox.getCaseNumber()){
				
				//If matched then will go through all of the evidences that is stored in the EvidenceBox
				
				for (int j = 0; j< evidenceBox.allEvidences().size();j++){
					Evidence evidence = evidenceBox.allEvidences().get(j);
					tempEvidence.add(evidence);
					
					//then will check whether each of the evidence matches the desiredEvidence
					
					if(desiredEvidence.equals(evidence.getEvidence())){
						
						//If matched then will add to an array of his DesiredEvidences ArrayList
						
						desiredEvidences.add(evidence);
					}
				}
			}
		}
		System.out.println("Pieces of " + desiredEvidence +" evidence in Evidence Box number " + 
		+caseNumber + " found by " + name + " : " + desiredEvidences );
	 
	}
	
	/**
	 * A to-string method to print the name of the policeman object when it is called for printing
	 */
	
	public String toString(){
		return name;
	}
}
